OK_FORMAT = True

test = {   'name': 'q3.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(np.round(np.sum(wind_mag), decimals=2)) == '872e27abbbc3735010e8d1f58ae6c465'\n",
                                       'failure_message': 'Check the wind magnitude computation.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
