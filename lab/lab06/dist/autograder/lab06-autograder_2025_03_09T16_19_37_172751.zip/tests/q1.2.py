OK_FORMAT = True

test = {   'name': 'q1.2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(len(x_q1)) == 'a9b7ba70783b617e9998dc4dd82eb3c5'\n"
                                               ">>> assert get_hash(np.round(np.sum(x_q1), decimals=2)) == '3b68e4b87a954d6116e95334c6c59068'\n",
                                       'failure_message': 'Check the x grid.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.4},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(u_t0), decimals=2)) == '47bff7aaf1ec63d5d71200ec4177fd02', 'Check u_t0.'\n"
                                               ">>> assert get_hash(np.round(np.sum(u_t50), decimals=2)) == '643c90867bbecb6e12ceb9c61a9fc180', 'Check u_t50.'\n"
                                               ">>> assert get_hash(np.round(np.sum(u_t150), decimals=2)) == '9f985f523aa3f1bc1e9c410ccd67f1fe', 'Check u_t150.'\n",
                                       'failure_message': 'Check u_t0, u_t50 and u_t150.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.6}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
