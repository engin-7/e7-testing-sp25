OK_FORMAT = True

test = {   'name': 'q4.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert type(fig_6).__name__ == 'Figure'\n",
                                       'failure_message': 'Make sure to create a figure and assign it to fig_6.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> xdata, ydata, zdata, _ = fig_6.axes[0].collections[0]._vec\n'
                                               ">>> assert get_hash(np.round(np.sum(xdata), decimals=2)) == '45dcb15d4c225238b928e63f5eddd474', ' Check plot X data.'\n"
                                               ">>> assert get_hash(np.round(np.sum(ydata), decimals=2)) == '99ea2a082321fad1f9d6775a288759ce', ' Check plot Y data.'\n"
                                               ">>> assert get_hash(np.round(np.sum(zdata), decimals=2)) == 'b96696b59c1361b5c320f9264a005165', ' Check plot Z data.'\n",
                                       'failure_message': 'Check plot X,Y,Z data.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': ">>> assert fig_6.axes[0].get_children()[0].get_cmap().name == 'plasma', 'Check colormap.'\n",
                                       'failure_message': 'Check the colormap.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert fig_6.axes[0].get_aspect() == 'equal', 'Check the axes aspect ratio.'\n",
                                       'failure_message': 'Check axis aspect ratio.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert 'X' in fig_6.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert fig_6.axes[0].xaxis.label.get_fontsize() == 12, 'Check the x-axis label fontsize.'\n"
                                               ">>> assert 'Y' in fig_6.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert fig_6.axes[0].yaxis.label.get_fontsize() == 12, 'Check the y-axis label fontsize.'\n"
                                               ">>> assert 'Z' in fig_6.axes[0].get_zlabel().upper(), 'Check the z-axis label.'\n"
                                               ">>> assert fig_6.axes[0].zaxis.label.get_fontsize() == 12, 'Check the y-axis label fontsize.'\n",
                                       'failure_message': 'Check the axis labels and font sizes.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> title_string = ['NATURAL', 'MODE', 'SHAPE', 'M', '3', 'N', '2']\n"
                                               ">>> assert all((word in fig_6.axes[0].get_title().upper() for word in title_string)), 'Check the title label.'\n"
                                               ">>> assert fig_6.axes[0].title.get_fontsize() == 14, 'Check the title label fontsize.'\n",
                                       'failure_message': 'Check title label and font size.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
