OK_FORMAT = True

test = {   'name': 'q3.4',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert type(fig_5).__name__ == 'Figure'\n",
                                       'failure_message': 'Make sure to create a figure and assign it to fig_5.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert np.isclose(np.sum(vel_quiver.X), np.sum(wind_x), rtol=0.01), 'Check quiver plot X data.'\n"
                                               ">>> assert np.isclose(np.sum(vel_quiver.Y), np.sum(wind_y), rtol=0.01), 'Check quiver plot Y data.'\n"
                                               ">>> assert np.isclose(np.sum(vel_quiver.U), np.sum(wind_vx), rtol=0.01), 'Check quiver plot U data.'\n"
                                               ">>> assert np.isclose(np.sum(vel_quiver.V), np.sum(wind_vy), rtol=0.01), 'Check quiver plot V data.'\n",
                                       'failure_message': 'Check the plot data.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': ">>> title_string = ['WIND', 'VELOCITY', 'FIELD']\n>>> assert all((word in fig_5.axes[0].get_title().upper() for word in title_string))\n",
                                       'failure_message': 'Check the title label.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': ">>> assert 'MAGNITUDE' in cbar_wind.ax.get_ylabel().upper(), 'Check the colorbar label.'\n",
                                       'failure_message': 'Make sure to add a labeled colorbar.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert grid.collection_kwargs['alpha'] == 0.5, 'Check grid alpha'\n"
                                               ">>> assert grid.collection_kwargs['linestyle'] == ':', 'Check grid linestyle'\n"
                                               ">>> assert grid.collection_kwargs['color'] == 'k', 'Check grid color'\n",
                                       'failure_message': 'Check the grid.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> assert fig_5.axes[0].get_xlim() == (-134.3, -70.188), \'Check the x-axis limits. Make sure to specify "crs".\'\n'
                                               '>>> assert fig_5.axes[0].get_ylim() == (17.5, 60.0), \'Check the y-axis limits. Make sure to specify "crs".\'\n',
                                       'failure_message': 'Check the axis limits.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': '>>> import matplotlib\n'
                                               '>>> assert np.isclose(np.sum(matplotlib.cm.ScalarMappable(norm=vel_quiver.norm, cmap=vel_quiver.cmap).to_rgba(wind_mag).flatten()), '
                                               'np.sum(vel_quiver.get_facecolor().flatten()), rtol=0.01)\n',
                                       'failure_message': 'Make sure to use the wind magnitude as the colormap key.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
