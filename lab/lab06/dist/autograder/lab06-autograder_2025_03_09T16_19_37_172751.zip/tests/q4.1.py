OK_FORMAT = True

test = {   'name': 'q4.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(len(x_q4_1)) == 'a9b7ba70783b617e9998dc4dd82eb3c5'\n"
                                               ">>> assert get_hash(np.round(np.sum(x_q4_1), decimals=2)) == '1c51ac3926a046148a24ba048afc85cd'\n",
                                       'failure_message': 'Check 1D x grid.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(len(y_q4_1)) == 'a9b7ba70783b617e9998dc4dd82eb3c5'\n"
                                               ">>> assert get_hash(np.round(np.sum(y_q4_1), decimals=2)) == '1434f81012ce9c2aba692d5177889ef4'\n",
                                       'failure_message': 'Check 1D y grid.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(X_q4_1.shape) == '2c279ef3676bba689eabb103f0a319e8'\n"
                                               ">>> assert get_hash(np.round(np.sum(X_q4_1), decimals=2)) == 'ead4a206965a49fc387fd5b4de90867c'\n",
                                       'failure_message': 'Check 2D X grid.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(Y_q4_1.shape) == '2c279ef3676bba689eabb103f0a319e8'\n"
                                               ">>> assert get_hash(np.round(np.sum(Y_q4_1), decimals=2)) == 'be6a5089b8e4ba482c427df57552ad5f'\n",
                                       'failure_message': 'Check 2D Y grid.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(Z_q4_1.shape) == '2c279ef3676bba689eabb103f0a319e8'\n"
                                               ">>> assert get_hash(np.round(np.sum(Z_q4_1), decimals=2)) == '30565a8911a6bb487e3745c0ea3c8224'\n",
                                       'failure_message': 'Check Z grid.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
