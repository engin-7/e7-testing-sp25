OK_FORMAT = True

test = {   'name': 'q1.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(rho) == '1637533ef837128ee0199716d73687bd', 'Check rho.'\n"
                                               ">>> assert get_hash(k) == '248a7444f08189bb31ba143eabebe4e5', 'Check k.'\n"
                                               ">>> assert get_hash(c) == '052fbf0fbad7b4a752d34e1dc0e76cfa', 'Check c.'\n"
                                               ">>> assert get_hash(np.round(alpha, decimals=2)) == '695ec0ee7352c033530309d0ad3418cb', 'Check alpha.'\n"
                                               ">>> assert get_hash(np.round(lam_sq, decimals=2)) == '04817efd11c15364a6ec239780038862', 'Check lam_sq.'\n",
                                       'failure_message': 'Check constants.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': ">>> assert callable(u) and u.__name__ == '<lambda>'\n",
                                       'failure_message': 'Make sure it is a lambda function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': ">>> assert get_hash(np.round(u(0, 100), decimals=2)) == '30565a8911a6bb487e3745c0ea3c8224'\n"
                                               ">>> assert get_hash(np.round(u(10, 10), decimals=2)) == '19ca1e8274ab2a38604c8baa84ef7baa'\n"
                                               ">>> assert get_hash(np.round(u(60, 30), decimals=2)) == '89dbc31f785433f9aeefa440b26f01a7'\n"
                                               ">>> assert get_hash(np.round(u(100, 100), decimals=2)) == '30565a8911a6bb487e3745c0ea3c8224'\n"
                                               ">>> assert callable(u) and u.__name__ == '<lambda>'\n",
                                       'failure_message': 'Check your u function.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> x = np.linspace(0, 100)\n'
                                               ">>> assert get_hash(len(u(x, 10))) == 'c0c7c76d30bd3dcaefc96f40275bdc0a'\n"
                                               ">>> assert get_hash(np.round(np.sum(u(x, 10)), decimals=2)) == 'dd665bc9865f92f5c247d793c1f5c019'\n"
                                               ">>> assert callable(u) and u.__name__ == '<lambda>'\n",
                                       'failure_message': 'Make sure your u function works on array inputs.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
