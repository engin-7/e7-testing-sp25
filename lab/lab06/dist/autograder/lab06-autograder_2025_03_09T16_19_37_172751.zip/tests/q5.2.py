OK_FORMAT = True

test = {   'name': 'q5.2',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert type(fig_9).__name__ == 'Figure'\n",
                                       'failure_message': 'Make sure to create a figure and assign it to fig_9.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(vr.shape) == '2c279ef3676bba689eabb103f0a319e8'\n"
                                               ">>> assert get_hash(np.round(np.sum(vr), decimals=2)) == '75cd8970acd3ddaa0d10134c11c32ce7'\n",
                                       'failure_message': 'Check radial velocity (vr) calculation.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(vt.shape) == '2c279ef3676bba689eabb103f0a319e8'\n"
                                               ">>> assert get_hash(np.round(np.sum(vt), decimals=2)) == 'e80c77464a0cfaf2c46a5574f6bc76b9'\n",
                                       'failure_message': 'Check transverse velocity (vt) calculation.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert v_quiver.scale == 200, 'Check quiver plot scale.'\n"
                                               ">>> assert len(v_quiver.X) == 1600, 'Make sure to plot at every 25th grid point only.'\n"
                                               ">>> assert get_hash(np.round(np.sum(v_quiver.X), decimals=2)) == '5ab881cdc85e2fc2abe9a30734de1b5b', 'Make sure to plot at every 25th grid point "
                                               "only.'\n"
                                               ">>> assert len(v_quiver.Y) == 1600, 'Make sure to plot at every 25th grid point only.'\n"
                                               ">>> assert get_hash(np.round(np.sum(v_quiver.Y), decimals=2)) == 'bb42d52e328cb7ecb4a0732d34fd1a71', 'Make sure to plot at every 25th grid point "
                                               "only.'\n",
                                       'failure_message': 'Check quiver plot properties. Make sure to plot at every 25th grid point only.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert v_contour.get_cmap().name == 'jet', 'Check v_contour colormap.'\n"
                                               ">>> assert 20 < len(v_contour.levels) < 40, 'Check v_contour levels.'\n"
                                               ">>> assert get_hash(np.round(np.sum(v_contour.allsegs[1][0]), decimals=2)) == '74589c650b9d084383414e93522164d6', 'Check v_contour plot data.'\n",
                                       'failure_message': 'Check contour plot properties.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert len(cbar_vel.get_ticks()) == 2, 'Check colorbar ticks.'\n"
                                               ">>> assert np.isclose(cbar_vel.get_ticks()[0], 0, rtol=0.01), 'Check colorbar ticks.'\n"
                                               ">>> assert np.isclose(cbar_vel.get_ticks()[1], 19.99, rtol=0.01), 'Check colorbar ticks.'\n"
                                               ">>> assert cbar_vel.ax.get_yticklabels()[0].get_text() == 'Low', 'Check colorbar ticks.'\n"
                                               ">>> assert cbar_vel.ax.get_yticklabels()[1].get_text() == 'High', 'Check colorbar ticks.'\n",
                                       'failure_message': 'Check colorbar.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert 'X' in fig_9.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert fig_9.axes[0].xaxis.label.get_fontsize() == 12, 'Check the x-axis label fontsize.'\n"
                                               ">>> assert 'Y' in fig_9.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert fig_9.axes[0].yaxis.label.get_fontsize() == 12, 'Check the y-axis label fontsize.'\n"
                                               ">>> assert 'VELOCITY' in fig_9.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'FIELD' in fig_9.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert fig_9.axes[0].title.get_fontsize() == 14, 'Check the title label fontsize.'\n",
                                       'failure_message': 'Check title and axis labels.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert fig_9.axes[0].get_xlim() == (-3, 3), 'Check the x-axis limits.'\n"
                                               ">>> assert fig_9.axes[0].get_ylim() == (-3, 3), 'Check the y-axis limits.'\n"
                                               ">>> assert len(fig_9.axes[0].get_xticks()) == 0, 'Check the x-axis ticks.'\n"
                                               ">>> assert len(fig_9.axes[0].get_yticks()) == 0, 'Check the y-axis ticks.'\n",
                                       'failure_message': 'Check axis limits.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
