OK_FORMAT = True

test = {   'name': 'q3.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(wind_x, np.ndarray), 'Make sure wind_x is assigned and is a numpy array.'\n"
                                               ">>> assert isinstance(wind_y, np.ndarray), 'Make sure wind_y is assigned and is a numpy array.'\n"
                                               ">>> assert isinstance(wind_vx, np.ndarray), 'Make sure wind_vx is assigned and is a numpy array.'\n"
                                               ">>> assert isinstance(wind_vy, np.ndarray), 'Make sure wind_vy is assigned and is a numpy array.'\n",
                                       'failure_message': 'Check the variable names and make sure they are numpy arrays.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(wind_x), decimals=2)) == '191f944a56e709fed4cbba9cbe4c8bd0', 'Check the wind_x data.'\n"
                                               ">>> assert get_hash(np.round(np.sum(wind_y), decimals=2)) == 'cf87726119a3db49884cc2e364dbe32a', 'Check the wind_y data.'\n"
                                               ">>> assert get_hash(np.round(np.sum(wind_vx), decimals=2)) == '02e71c8357f8983537872ad2f30580e4', 'Check the wind_vx data.'\n"
                                               ">>> assert get_hash(np.round(np.sum(wind_vy), decimals=2)) == 'dda186858e2cec344497f604ebb95dab', 'Check the wind_vy data.'\n",
                                       'failure_message': "Make sure you've read all data files correctly.",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
