OK_FORMAT = True

test = {   'name': 'q2.0',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(eq_data.shape) == '86475183e983421e2c569d248a56dd25'\n", 'failure_message': 'Check the read command.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
