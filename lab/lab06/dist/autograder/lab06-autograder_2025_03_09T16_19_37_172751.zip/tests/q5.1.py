OK_FORMAT = True

test = {   'name': 'q5.1',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert type(fig_8).__name__ == 'Figure'\n",
                                       'failure_message': 'Make sure to create a figure and assign it to fig_8.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(X_q5_1.shape) == '2c279ef3676bba689eabb103f0a319e8'\n"
                                               ">>> assert get_hash(np.round(np.sum(X_q5_1), decimals=2)) == '381a7a26ff2526446cbb97fee6f8505a'\n",
                                       'failure_message': 'Check 2D x grid.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(Y_q5_1.shape) == '2c279ef3676bba689eabb103f0a319e8'\n"
                                               ">>> assert get_hash(np.round(np.sum(Y_q5_1), decimals=2)) == '30565a8911a6bb487e3745c0ea3c8224'\n",
                                       'failure_message': 'Check 2D y grid.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(velocity_contour.allsegs[1][0]), decimals=2)) == 'ba469849bf567c4e8007be1b7b91e6bc'\n",
                                       'failure_message': 'Check velocity plot data.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(stream_contour.allsegs[1][0]), decimals=2)) == '31bcc38792a1d10af55283d998eea9c1'\n",
                                       'failure_message': 'Check streamline plot data.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert len(cbar_pressure.get_ticks()) == 2, 'Check colorbar ticks.'\n"
                                               ">>> assert np.isclose(cbar_pressure.get_ticks()[0], -150, rtol=0.01), 'Check colorbar ticks.'\n"
                                               ">>> assert np.isclose(cbar_pressure.get_ticks()[1], 50, rtol=0.01), 'Check colorbar ticks.'\n"
                                               ">>> assert cbar_pressure.ax.get_yticklabels()[0].get_text().upper() == 'LOW', 'Check colorbar ticks.'\n"
                                               ">>> assert cbar_pressure.ax.get_yticklabels()[1].get_text().upper() == 'HIGH', 'Check colorbar ticks.'\n",
                                       'failure_message': 'Check the colorbar.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert pressure_contour.get_cmap().name == 'jet', 'Check pressure_contour colormap.'\n"
                                               ">>> assert 45 < len(pressure_contour.allsegs) < 55, 'Check pressure_contour levels.'\n",
                                       'failure_message': 'Check pressure plot properites.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert 45 < len(stream_contour.allsegs) < 55, 'Check stream_contour levels.'\n",
                                       'failure_message': 'Check streamline contour plot properites.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert 45 < len(velocity_contour.levels) < 55, 'Check velocity contour levels.'\n",
                                       'failure_message': 'Check velocity potential contour plot properites.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert 'X' in fig_8.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert fig_8.axes[0].xaxis.label.get_fontsize() == 12, 'Check the x-axis label fontsize.'\n"
                                               ">>> assert 'Y' in fig_8.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert fig_8.axes[0].yaxis.label.get_fontsize() == 12, 'Check the y-axis label fontsize.'\n"
                                               ">>> assert 'PRESSURE' in fig_8.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'FIELD' in fig_8.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert fig_8.axes[0].title.get_fontsize() == 14, 'Check the title label fontsize.'\n",
                                       'failure_message': 'Check title and axis labels.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert fig_8.axes[0].get_xlim() == (-5, 5), 'Check the x-axis limits.'\n"
                                               ">>> assert fig_8.axes[0].get_ylim() == (-5, 5), 'Check the y-axis limits.'\n"
                                               ">>> assert len(fig_8.axes[0].get_xticks()) == 0, 'Check the x-axis ticks.'\n"
                                               ">>> assert len(fig_8.axes[0].get_yticks()) == 0, 'Check the y-axis ticks.'\n",
                                       'failure_message': 'Check axis limits and ticks.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
