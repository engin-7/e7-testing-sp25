OK_FORMAT = True

test = {   'name': 'q4.3',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert type(fig_7).__name__ == 'Figure'\n",
                                       'failure_message': 'Make sure to create a figure and assign it to fig_7.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert axs.shape == (2, 2)\n',
                                       'failure_message': 'Make sure you have a 2x2 subplot layout stored in the variable "axs".',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(len(x_q4_3)) == 'a9b7ba70783b617e9998dc4dd82eb3c5'\n"
                                               ">>> assert get_hash(np.round(np.sum(x_q4_3), decimals=2)) == '02541b7cbb840b5f6bd8eff3c9f56f61'\n",
                                       'failure_message': 'Check 1D x grid.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': ">>> assert get_hash(len(y_q4_3)) == 'a9b7ba70783b617e9998dc4dd82eb3c5'\n"
                                               ">>> assert get_hash(np.round(np.sum(y_q4_3), decimals=2)) == '02541b7cbb840b5f6bd8eff3c9f56f61'\n",
                                       'failure_message': 'Check 1D y grid.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': ">>> assert get_hash(X_q4_3.shape) == '2c279ef3676bba689eabb103f0a319e8'\n"
                                               ">>> assert get_hash(np.round(np.sum(X_q4_3), decimals=2)) == '21819d66f20373895e5f413cfe0e5c0f'\n",
                                       'failure_message': 'Check 2D X grid.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': ">>> assert get_hash(len(Y_q4_3)) == 'a9b7ba70783b617e9998dc4dd82eb3c5'\n"
                                               ">>> assert get_hash(np.round(np.sum(Y_q4_3), decimals=2)) == '21819d66f20373895e5f413cfe0e5c0f'\n",
                                       'failure_message': 'Check 2D Y grid.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': '>>> lst = [1, 2]\n'
                                               '>>> for m in lst:\n'
                                               '...     for n in lst:\n'
                                               '...         xdata, ydata, zdata, _ = axs[m - 1, n - 1].collections[0]._vec\n'
                                               "...         assert get_hash(np.round(np.sum(xdata), decimals=2)) == '3a91fa7fa6da2692cfbd6742e79c06e2'\n"
                                               "...         assert get_hash(np.round(np.sum(ydata), decimals=2)) == '3a91fa7fa6da2692cfbd6742e79c06e2'\n"
                                               '>>> _, _, zdata, _ = axs[0, 0].collections[0]._vec\n'
                                               ">>> assert get_hash(np.round(np.sum(zdata), decimals=2)) == 'a6858f8d22e7550f5bd8cc577a2da5ea', 'Check subplot [0,0] Z data.'\n"
                                               '>>> _, _, zdata, _ = axs[0, 1].collections[0]._vec\n'
                                               ">>> assert get_hash(np.round(np.sum(zdata[100:1000]), decimals=2)) == '8a642ee1b6c4050e12230e0041b2b616', 'Check subplot [0,1] Z data.'\n"
                                               '>>> _, _, zdata, _ = axs[1, 0].collections[0]._vec\n'
                                               ">>> assert get_hash(np.round(np.sum(zdata[100:1000]), decimals=2)) == '3646f381f72d82c4e705fef08499596f', 'Check subplot [1,0] Z data.'\n"
                                               '>>> _, _, zdata, _ = axs[1, 1].collections[0]._vec\n'
                                               ">>> assert get_hash(np.round(np.sum(zdata), decimals=13)) == '6675b023fa02f39f69de008a601c300b', 'Check subplot [1,1] Z data.'\n",
                                       'failure_message': 'Check X,Y,Z data of subplots.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': ">>> assert fig_7._suptitle.get_text() == 'Mode shapes', 'Check figure suptitle.'\n"
                                               ">>> assert fig_7._suptitle.get_fontsize() == 16, 'Check figure suptitle font size.'\n",
                                       'failure_message': 'Check suptitle and font size.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': '>>> lst = [1, 2]\n'
                                               '>>> for m in lst:\n'
                                               '...     for n in lst:\n'
                                               "...         assert axs[m - 1, n - 1].get_xlabel().upper() == 'X', 'Check x-axis labels.'\n"
                                               "...         assert axs[m - 1, n - 1].get_ylabel().upper() == 'Y', 'Check y-axis labels.'\n"
                                               "...         assert axs[m - 1, n - 1].get_zlabel().upper() == 'Z', 'Check z-axis labels.'\n"
                                               "...         assert axs[m - 1, n - 1].get_title() == 'm = {m}, n = {n}'.format(m=m, n=n), 'Check title labels.'\n",
                                       'failure_message': 'Check subplot labels and titles.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': ">>> lst = [1, 2]\n>>> for m in lst:\n...     for n in lst:\n...         assert axs[m - 1, n - 1].get_children()[0].get_cmap().name == 'coolwarm'\n",
                                       'failure_message': 'Check subplot colormaps.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
