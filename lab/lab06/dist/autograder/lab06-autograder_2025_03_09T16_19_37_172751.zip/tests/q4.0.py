OK_FORMAT = True

test = {   'name': 'q4.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q4_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(np.round(mode_shape(0.2, 0.6, 1, 1, 1, 1), decimals=2)) == '2363c78ab7dba59b8443d958b47cfa2b'\n"
                                               ">>> assert get_hash(np.round(mode_shape(0.23, 0.7, 1, 1, 1, 1), decimals=2)) == '676813538852c7111802c95f5ca99e41'\n"
                                               ">>> assert get_hash(np.round(mode_shape(0.3, 0.3, 1, 1, 1, 1), decimals=2)) == '136ba81d3813591cdcc15fcb924b9437'\n"
                                               ">>> assert get_hash(np.round(mode_shape(0.7, 0.8, 1, 1, 1, 1), decimals=2)) == '451d13a5be2581a451c2284dcecddd4e'\n",
                                       'failure_message': 'Check your mode_shape function.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3},
                                   {   'code': ">>> assert get_hash(np.round(mode_shape(0.23, 0.7, 1, 1, 3, 4), decimals=2)) == 'ab01272978f4106a12ede6fe2a850be4'\n"
                                               ">>> assert get_hash(np.round(mode_shape(0.3, 0.3, 1, 2, 8, 1), decimals=2)) == '91afec64e32d6bf957e441df2ab638bb'\n"
                                               ">>> assert get_hash(np.round(mode_shape(0.7, 0.8, 2, 2, 5, 5), decimals=2)) == '30565a8911a6bb487e3745c0ea3c8224'\n",
                                       'failure_message': 'Check your mode_shape function.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3},
                                   {   'code': '>>> x = np.linspace(0, 1)\n'
                                               ">>> assert get_hash(len(mode_shape(x, x, 1, 1, 1, 1))) == 'c0c7c76d30bd3dcaefc96f40275bdc0a'\n"
                                               ">>> assert get_hash(np.round(np.sum(mode_shape(x, x, 2, 2, 1, 1)), decimals=2)) == '483caca5435deb51f412fc8d3932f4a3'\n",
                                       'failure_message': 'Make sure your mode_shape function works on array inputs.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
