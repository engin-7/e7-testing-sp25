OK_FORMAT = True

test = {   'name': 'q1.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert type(fig_1).__name__ == 'Figure'\n",
                                       'failure_message': 'Make sure to create a figure and assign it to fig_1.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[0].get_xdata()), decimals=2)) == '3b68e4b87a954d6116e95334c6c59068'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[0].get_ydata()), decimals=2)) == '47bff7aaf1ec63d5d71200ec4177fd02'\n",
                                       'failure_message': 'Check x and y data of line plot 1.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[1].get_xdata()), decimals=2)) == '3b68e4b87a954d6116e95334c6c59068'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[1].get_ydata()), decimals=2)) == '643c90867bbecb6e12ceb9c61a9fc180'\n",
                                       'failure_message': 'Check x and y data of line plot 2.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[2].get_xdata()), decimals=2)) == '3b68e4b87a954d6116e95334c6c59068'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[2].get_ydata()), decimals=2)) == '9f985f523aa3f1bc1e9c410ccd67f1fe'\n",
                                       'failure_message': 'Check x and y data of line plot 3.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert fig_1.axes[0].get_lines()[0].get_linestyle() == '-'\n"
                                               ">>> assert fig_1.axes[0].get_lines()[1].get_linestyle() == '--'\n"
                                               ">>> assert fig_1.axes[0].get_lines()[2].get_linestyle() == '-.'\n",
                                       'failure_message': 'Check linestyles.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert fig_1.axes[0].get_lines()[0].get_color() == 'b'\n"
                                               ">>> assert fig_1.axes[0].get_lines()[1].get_color() == 'r'\n"
                                               ">>> assert fig_1.axes[0].get_lines()[2].get_color() == 'g'\n",
                                       'failure_message': 'Check line colors.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert fig_1.axes[0].get_lines()[0].get_label() == 't = 0s'\n"
                                               ">>> assert fig_1.axes[0].get_lines()[1].get_label() == 't = 50s'\n"
                                               ">>> assert fig_1.axes[0].get_lines()[2].get_label() == 't = 150s'\n",
                                       'failure_message': 'Check line labels.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> x_string = ['X', 'CM']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_xlabel().upper() for word in x_string]), 'Check the x-axis label.'\n"
                                               ">>> assert fig_1.axes[0].xaxis.label.get_fontsize() == 14, 'Check the x-axis label fontsize.'\n"
                                               ">>> y_string = ['TEMPERATURE', 'DEGREES', 'CELSIUS']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_ylabel().upper() for word in y_string]), 'Check the y-axis label.'\n"
                                               ">>> assert fig_1.axes[0].yaxis.label.get_fontsize() == 14, 'Check the y-axis label fontsize.'\n",
                                       'failure_message': 'Check figure labels and font sizes.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> title_string = ['TEMPERATURE', 'DISTRIBUTION', 'COPPER', 'BAR']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_title().upper() for word in title_string]), 'Check the title label.'\n"
                                               ">>> assert fig_1.axes[0].title.get_fontsize() == 16, 'Check the title label fontsize.'\n",
                                       'failure_message': 'Check title and font sizes.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> assert type(fig_1.axes[0].get_legend()) != type(None)\n',
                                       'failure_message': 'Make sure to add a legend.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': ">>> assert fig_1.axes[0].get_xlim() == (0.0, 100.0), 'Check the x-axis limits.'\n"
                                               ">>> assert fig_1.axes[0].get_ylim() == (-120.0, 120.0), 'Check the y-axis limits.'\n",
                                       'failure_message': 'Check axis limits.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
