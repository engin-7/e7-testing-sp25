OK_FORMAT = True

test = {   'name': 'q2.2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert type(fig_3).__name__ == 'Figure'\n",
                                       'failure_message': 'Make sure to create a figure and assign it to fig_3.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert np.isclose(np.sum(eq_scatter.get_offsets()[:, 0]), np.sum(eq_data[:, 1]), rtol=0.01)\n'
                                               '>>> assert np.isclose(np.sum(eq_scatter.get_offsets()[:, 1]), np.sum(eq_data[:, 0]), rtol=0.01)\n',
                                       'failure_message': 'Check plot data.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> assert np.isclose(np.sum(eq_scatter.get_sizes()), np.sum(eq_data[:, 2] ** 4), rtol=0.01)\n',
                                       'failure_message': 'Check marker sizes.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> import matplotlib\n'
                                               '>>> assert np.isclose(np.sum(matplotlib.cm.ScalarMappable(norm=eq_scatter.norm, cmap=eq_scatter.cmap).to_rgba(eq_data[:, 2], alpha=0.5).flatten()), '
                                               'np.sum(eq_scatter.get_facecolor().flatten()), rtol=0.01)\n',
                                       'failure_message': 'Check marker colors.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.75},
                                   {   'code': ">>> title_string = ['CA', 'EARTHQUAKES', '2022']\n>>> assert all((word in fig_3.axes[0].get_title().upper() for word in title_string))\n",
                                       'failure_message': 'Check the title.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {'code': ">>> assert 'MAGNITUDE' in cbar_eq.ax.get_ylabel().upper()\n", 'failure_message': 'Check the colorbar.', 'hidden': False, 'locked': False, 'points': 0.25},
                                   {   'code': ">>> assert grid.collection_kwargs['alpha'] == 0.5, 'Check grid alpha'\n"
                                               ">>> assert grid.collection_kwargs['linestyle'] == ':', 'Check grid linestyle'\n"
                                               ">>> assert grid.collection_kwargs['color'] == 'k', 'Check grid color'\n",
                                       'failure_message': 'Check the grid (alpha, linestyle, and color).',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
