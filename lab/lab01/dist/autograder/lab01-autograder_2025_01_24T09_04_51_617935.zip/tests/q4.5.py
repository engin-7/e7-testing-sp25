OK_FORMAT = True

test = {   'name': 'q4.5',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> q3_0_vars = ['China_per_capita', 'Qatar_per_capita', 'USA_per_capita']\n>>> assert all([var_name in globals() for var_name in q3_0_vars])\n",
                                       'failure_message': 'Check variable names.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(China_per_capita) == '2e08fabaf262a0fea4da5c818c9894e2'\n"
                                               ">>> assert get_hash(Qatar_per_capita) == '2f56f1561f0c21041643671d4fd9f85a'\n"
                                               ">>> assert get_hash(USA_per_capita) == 'c89b4e5c27b4928beff41e7782689f91'\n",
                                       'failure_message': 'Check variable values.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
