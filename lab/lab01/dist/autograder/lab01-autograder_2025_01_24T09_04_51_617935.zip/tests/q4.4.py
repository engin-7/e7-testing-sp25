OK_FORMAT = True

test = {   'name': 'q4.4',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(q4_4) == '2993d6c487b8101c0701534ba325cb91'\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> assert get_hash(Qatar_CO2) == '26657d5ff9020d2abefe558796b99584'\n",
                                       'failure_message': 'Do not reassign the variable.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
