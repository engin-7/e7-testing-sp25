OK_FORMAT = True

test = {   'name': 'q3.3',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q3_3, 3)) == '5bda95602d31edf4ea2526dd3c8b078f'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
