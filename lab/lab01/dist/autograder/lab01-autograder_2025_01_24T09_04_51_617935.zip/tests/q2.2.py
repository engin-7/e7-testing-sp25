OK_FORMAT = True

test = {   'name': 'q2.2',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(q2_2.upper()) == 'f623e75af30e62bbd73d6df5b50bb7b5'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Correct! Long assignment extension requests (> 48 hours) should be submitted before Friday 11:59 PM, and NOT within the 48-hour grace '
                                                          'period.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
