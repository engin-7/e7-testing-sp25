OK_FORMAT = True

test = {   'name': 'q3.1',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q3_1, 2)) == '10f8e19d19bf3772687b5457a689fa21'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
