OK_FORMAT = True

test = {   'name': 'q3.7',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q3_7, 4)) == '3205c5a0e0c890e0113e87dd3b5d7349'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
