OK_FORMAT = True

test = {   'name': 'q4.7',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> \n>>> assert get_hash(q4_7a) == 'f827cf462f62848df37c5e1e94a4da74'\n", 'failure_message': 'Check q4_7a.', 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> assert get_hash(q4_7b) == 'f8320b26d30ab433c5a54546d21f414c'\n",
                                       'failure_message': 'Check q4_7b.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {'code': ">>> \n>>> assert get_hash(q4_7) == 'f827cf462f62848df37c5e1e94a4da74'\n", 'failure_message': 'Check q4_7.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
