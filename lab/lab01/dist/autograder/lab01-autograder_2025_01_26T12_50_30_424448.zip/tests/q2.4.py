OK_FORMAT = True

test = {   'name': 'q2.4',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q2_4.upper()) == '9d5ed678fe57bcca610140957afab571'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
