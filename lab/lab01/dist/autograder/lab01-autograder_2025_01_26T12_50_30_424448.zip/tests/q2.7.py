OK_FORMAT = True

test = {   'name': 'q2.7',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> assert get_hash(q2_7.upper()) == '0d61f8370cad1d412f80b84d143e1257'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Correct! If you do not save your notebook before running the last cell, your submission might be missing any code that was recently added '
                                                          'and you will not receive any credit for the missing parts.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
