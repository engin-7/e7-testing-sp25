OK_FORMAT = True

test = {   'name': 'q4.0',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> assert len(q4_0.upper()) == 1\n>>> assert get_hash(q4_0.upper()) == '9d5ed678fe57bcca610140957afab571'\n",
                                       'failure_message': 'Incorrect answer. Make sure you have just the letter of your answer choice in quotes.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
