OK_FORMAT = True

test = {   'name': 'q3.8',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert (get_hash(round(q3_8, 3)) == 'c0857c1de732e77e7f99af3055dda037')\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
