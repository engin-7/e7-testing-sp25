OK_FORMAT = True

test = {   'name': 'q4.10',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q4_10) == 'f8320b26d30ab433c5a54546d21f414c'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
