OK_FORMAT = True

test = {   'name': 'q2.9',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q2_9.upper()) == '7fc56270e7a70fa81a5935b72eacbe29'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
