OK_FORMAT = True

test = {   'name': 'q2.3',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(q2_3.upper()) == '9d5ed678fe57bcca610140957afab571'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Correct! Plan to use your 2 lab drops for true emergencies only. No exceptions will be made to this policy.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
