OK_FORMAT = True

test = {   'name': 'q3.0',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(a) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n", 'failure_message': 'a', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(b) == '596a3d04481816330f07e4f97510c28f'\n", 'failure_message': 'b', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(c) == 'a87ff679a2f3e71d9181a67b7542122c'\n", 'failure_message': 'c', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(x) == 'c81e728d9d4c2f636f067f89cc14862c'\n", 'failure_message': 'x', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
