OK_FORMAT = True

test = {   'name': 'q4.3',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(q4_3) == 'c81e728d9d4c2f636f067f89cc14862c'\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> assert get_hash(Qatar_pop) == '23cb05d4a2e5bf28363909d92cd244e2'\n",
                                       'failure_message': 'Do not reassign the variable.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
