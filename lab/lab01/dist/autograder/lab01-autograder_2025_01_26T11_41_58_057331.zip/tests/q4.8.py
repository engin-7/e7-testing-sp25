OK_FORMAT = True

test = {   'name': 'q4.8',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(q4_8a) == 'f827cf462f62848df37c5e1e94a4da74'\n", 'failure_message': 'Check q4_8a.', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(q4_8b) == 'f827cf462f62848df37c5e1e94a4da74'\n", 'failure_message': 'Check q4_8b.', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(q4_8c) == 'f827cf462f62848df37c5e1e94a4da74'\n", 'failure_message': 'Check q4_8c.', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(q4_8) == 'f827cf462f62848df37c5e1e94a4da74'\n", 'failure_message': 'Check q4_8.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
