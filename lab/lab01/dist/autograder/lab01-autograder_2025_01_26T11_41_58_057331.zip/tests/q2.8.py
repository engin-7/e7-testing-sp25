OK_FORMAT = True

test = {   'name': 'q2.8',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(q2_8.upper()) == 'dfcf28d0734569a6a693bc8194de62bf'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Correct! Please do not email if you miss a lecture or are have issues accessing iClicker in class. You can take the online quiz instead. If '
                                                          'you are unable to take the online quiz, you can earn bonus points to make up for the missed lecture by answering questions correctly.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
