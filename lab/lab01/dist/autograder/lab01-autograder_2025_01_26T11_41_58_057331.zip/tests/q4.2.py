OK_FORMAT = True

test = {   'name': 'q4.2',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q4_2)) == '71f335aebe2d722b3351e4c9710a7236'\n",
                                       'failure_message': 'Check which function you used.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(q4_2) == '2203e3c2293eb8c9bda5bcd97acbf884'\n",
                                       'failure_message': 'Does the value have a fractional component?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
