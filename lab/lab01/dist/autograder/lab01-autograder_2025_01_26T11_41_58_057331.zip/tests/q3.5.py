OK_FORMAT = True

test = {   'name': 'q3.5',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q3_5, 4)) == '6140f47ca960c93adc21d0c11eef8f5f'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
