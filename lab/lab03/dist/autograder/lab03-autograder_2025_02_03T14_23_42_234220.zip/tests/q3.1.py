OK_FORMAT = True

test = {   'name': 'q3.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check function was tested\n>>> assert get_hash(type(q3_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> g = 9.81\n'
                                               ">>> assert get_hash(round(proj_distance(y0=0, v0=15, theta=40, x0=0),10)) == '473b4bccae9c0c4ee657741957329094'\n"
                                               ">>> assert get_hash(round(proj_distance(y0=10,v0=0, theta=45, x0=0),10)) == '30565a8911a6bb487e3745c0ea3c8224'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               ">>> assert get_hash(round(proj_distance(y0=0, v0=15, theta=40),10)) == '473b4bccae9c0c4ee657741957329094'\n"
                                               ">>> assert get_hash(round(proj_distance(y0=10,v0=0, theta=45),10)) == '30565a8911a6bb487e3745c0ea3c8224'\n"
                                               ">>> assert get_hash(round(proj_distance(y0=0, v0=15, theta=40, x0=2),10)) == 'cd863763b92481f1096331c9d79b5883'\n"
                                               ">>> assert get_hash(round(proj_distance(y0=10,v0=0, theta=45, x0=3),10)) == '55c82b601deae028c1c5e87fd820923d'\n",
                                       'failure_message': 'Check the default argument x0!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
