OK_FORMAT = True

test = {   'name': 'q4.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check function was tested\n>>> assert get_hash(type(q4_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> \n>>> # Check function returns a string\n>>> assert get_hash(type(q4_1)) == '9a86641cdf2fdb47f786dc955264738d'\n",
                                       'failure_message': 'Make sure your function returns a string!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash(box_pred(f=math.tan(math.radians(32)), theta=32.0)) == '7ea6c91dd27fef86440ca1c8636fb828'\n",
                                       'failure_message': 'What should happen if the actual angle is exactly equal to the critical angle?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash(box_pred(f=0.5, theta=30)) == '7ea6c91dd27fef86440ca1c8636fb828'\n"
                                               ">>> assert get_hash(box_pred(f=0.25, theta=10)) == '29a5a9cb0cfe9b668420c0b73345aa7a'\n"
                                               ">>> assert get_hash(box_pred(f=0.75, theta=30)) == '29a5a9cb0cfe9b668420c0b73345aa7a'\n"
                                               ">>> assert get_hash(box_pred(f=0.35, theta=25)) == '7ea6c91dd27fef86440ca1c8636fb828'\n"
                                               ">>> assert get_hash(box_pred(f=1/math.sqrt(3), theta=29.999)) == '29a5a9cb0cfe9b668420c0b73345aa7a'\n"
                                               ">>> assert get_hash(box_pred(f=1/math.sqrt(3), theta=30.001)) == '7ea6c91dd27fef86440ca1c8636fb828'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
