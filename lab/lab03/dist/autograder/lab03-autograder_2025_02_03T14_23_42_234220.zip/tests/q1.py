OK_FORMAT = True

test = {   'name': 'q1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check function was tested\n>>> assert get_hash(type(q1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash(np.round(solve_quadratic(5, -23, 2), 10)) == 'a5a94596c93b869b93e19acd21a6e879'\n"
                                               ">>> assert get_hash(np.round(solve_quadratic(1, 2, 1), 10)) == 'd98a89a61bd4adbd223683d56069916e'\n"
                                               ">>> assert get_hash(np.round(solve_quadratic(5.2, 3.5, -2.1), 10)) == '0c326748f52f4ce9452543ae27ac8698'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
