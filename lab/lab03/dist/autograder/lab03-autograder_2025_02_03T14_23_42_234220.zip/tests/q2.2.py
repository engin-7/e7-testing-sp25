OK_FORMAT = True

test = {   'name': 'q2.2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check function was tested\n>>> assert get_hash(type(q2_2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> \n>>> assert get_hash(round(exp_decay(6000),4)) == '65f9014d65dbcfbfa19c0f7fa6ab4da8'\n",
                                       'failure_message': 'Check default argument.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(round(exp_decay(10000,decay_constant=0.005),4)) == '30565a8911a6bb487e3745c0ea3c8224'\n"
                                               ">>> assert get_hash(round(exp_decay(5700,decay_constant=0.0005),4)) == 'f7c0bea0f6b8b0afb21183bd1fba47b5'\n"
                                               ">>> assert get_hash(round(exp_decay(1,decay_constant=0.5),4)) == '8a52647f06947d3d26632ec454dd25d7'\n"
                                               ">>> assert get_hash(round(exp_decay(106.34,decay_constant=0.0034),4)) == '58374b5008429c8708b89e0ff3cef80a'\n"
                                               ">>> assert get_hash(round(exp_decay(1456),4)) == 'ae9975b561135ecc09b35e7d203f41b3'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> \n>>> assert get_hash(np.round(exp_decay(np.array([5000, 6000])),10)) == '70c9b0267e9ba5e55ab35a8d64dac3b8'\n",
                                       'failure_message': 'Make sure your function can accept a NumPy array for time.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
