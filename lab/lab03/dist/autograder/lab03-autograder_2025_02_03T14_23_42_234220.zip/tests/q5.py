OK_FORMAT = True

test = {   'name': 'q5',
    'points': 4,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check function was tested\n>>> assert get_hash(type(q5)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> \n>>> # Check function returns a tuple\n>>> assert get_hash(type(q5)) == '22b3afce62075c7012f8e5041adfee16'\n",
                                       'failure_message': 'Make sure your function returns a tuple!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n>>> assert isinstance(q5[0], (int, float))\n',
                                       'failure_message': 'Make sure the first returned value is the price (numeric)!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n>>> assert isinstance(q5[1], str)\n',
                                       'failure_message': 'Make sure the second returned value is a string!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> usage = np.array([1, 1, 1, 1, 1, 1, 1, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 1, 1, 1, 1])\n'
                                               ">>> assert get_hash(round(best_plan(usage)[0], 4)) == '14dcbe1e1a4061a612e0a0cd5b00ac56'\n"
                                               ">>> assert get_hash(best_plan(usage)[1].upper()) == '105c61ad6b32ad3880685760d9b6b9aa'\n"
                                               '>>> usage = np.array([3.8, 2.4, 2.3, 1, 1, 1, 1, 7.5, 7.7, 7.9, 8, 8.8, 9, 9.5, 10, 10, 8.8, 7.6, 6.4, 5, 2.5, 4.2, 3.3, 3.4])\n'
                                               ">>> assert get_hash(round(best_plan(usage)[0], 4)) == 'be592cba6974b3373d6fb295c41f2f1f'\n"
                                               ">>> assert get_hash(best_plan(usage)[1].upper()) == '105c61ad6b32ad3880685760d9b6b9aa'\n"
                                               '>>> usage = np.array([1, 1, 1.2, 1.8, 8.9, 8.2, 8.7, 5.8, 10.7, 10.9, 15, 15.8, 16, 15.5, 6, 6, 5.8, 4.6, 53.4, 4.5, 4.5, 4.2, 1.3, 1.4])\n'
                                               ">>> assert get_hash(round(best_plan(usage)[0], 4)) == 'f2b2e05e843fde6473771dde0cd4c87d'\n"
                                               ">>> assert get_hash(best_plan(usage)[1].upper()) == '105c61ad6b32ad3880685760d9b6b9aa'\n",
                                       'failure_message': 'Check that your function calculates the cost of plan 1 correctly and chooses it as the best plan when it is the cheapest!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> \n'
                                               '>>> usage = np.array([1.8, 1.4, 2.3, 1.8, 10.9, 10.2, 10.7, 7.8, 7.7, 5.9, 5, 5.8, 6, 5.5, 6, 6, 5.8, 4.6, 13.4, 4.5, 4.5, 4.2, 1.3, 1.4])\n'
                                               ">>> assert get_hash(round(best_plan(usage)[0], 4)) == '13c40bba2995447063766ff3c66d3954'\n"
                                               ">>> assert get_hash(best_plan(usage)[1].upper()) == '753eb952bf2c7b40a232a08095245b0d'\n"
                                               '>>> usage = np.array([1.8, 1.4, 0.3, 0.8, 0.9, 0.2, 0.7, 0.8, 0.7, 15.9, 15, 10.4, 6, 5.5, 6, 6, 5.8, 4.6, 53.4, 4.5, 4.5, 4.2, 1.3, 1.4])\n'
                                               ">>> assert get_hash(round(best_plan(usage)[0], 4)) == '17848d4edca9ae698fa25ff6cbab33e4'\n"
                                               ">>> assert get_hash(best_plan(usage)[1].upper()) == '753eb952bf2c7b40a232a08095245b0d'\n",
                                       'failure_message': 'Check that your function calculates the cost of plan 2 correctly and chooses it as the best plan when it is the cheapest!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> \n'
                                               ">>> assert get_hash(round(best_plan(np.ones(24))[0], 4)) == 'e237633a8b413a04dd5028207f03c1c2'\n"
                                               ">>> assert get_hash(best_plan(np.ones(24))[1].upper()) == '35123f1448e59b7193db3c7d210589b3'\n"
                                               ">>> assert get_hash(round(best_plan(1.2*np.ones(24))[0], 4)) == '45dad2e50665b75b89b9c5e0697544ad'\n"
                                               ">>> assert get_hash(best_plan(1.2*np.ones(24))[1].upper()) == '35123f1448e59b7193db3c7d210589b3'\n"
                                               '>>> usage = np.array([5, 5, 5, 5, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 3, 3, 5, 5])\n'
                                               ">>> assert get_hash(round(best_plan(usage)[0], 4)) == 'ddd2e8c220072a5951b37078518ba809'\n"
                                               ">>> assert get_hash(best_plan(usage)[1].upper()) == '35123f1448e59b7193db3c7d210589b3'\n"
                                               '>>> usage = np.array([4, 3.5, 4.2, 5.6, 1, 1.2, 1.3, 2.2, 2.1, 2.5, 2, 2, 2, 2.8, 2, 2, 2, 1.1, 1.3, 1.4, 3.3, 3.2, 5.5, 5])\n'
                                               ">>> assert get_hash(round(best_plan(usage)[0], 4)) == '2a438ea6455149339336050fb8661259'\n"
                                               ">>> assert get_hash(best_plan(usage)[1].upper()) == '35123f1448e59b7193db3c7d210589b3'\n",
                                       'failure_message': 'Check that your function calculates the cost of plan 3 correctly and chooses it as the best plan when it is the cheapest!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
