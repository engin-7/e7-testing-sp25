OK_FORMAT = True

test = {   'name': 'q6',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check function was tested\n>>> assert get_hash(type(q6)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Check function returns a string\n'
                                               ">>> assert get_hash(type(decide_commute(rain=False, temperature=71))) == '9a86641cdf2fdb47f786dc955264738d'\n",
                                       'failure_message': 'Make sure your function returns a string!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               ">>> keywords = ['WORK', 'FROM', 'HOME']\n"
                                               '>>> r = [True, True, False]\n'
                                               '>>> t = [39, 105, 101]\n'
                                               '>>> assert all(word in decide_commute(r[i], t[i]).upper() for i in range(len(t)) for word in keywords)\n'
                                               '>>> \n'
                                               ">>> not_keywords = ['WALK', 'DRIVE']\n"
                                               '>>> assert all(word not in decide_commute(r[i], t[i]).upper() for i in range(len(t)) for word in not_keywords)\n',
                                       'failure_message': 'Check that your function works correctly for Work from Home',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> \n'
                                               ">>> keywords = ['WALK']\n"
                                               '>>> r = [False]*4\n'
                                               '>>> t = [70, 72, 78, 80]\n'
                                               '>>> assert all(word in decide_commute(r[i], t[i]).upper() for i in range(len(t)) for word in keywords)\n'
                                               '>>> \n'
                                               ">>> not_keywords = ['WORK', 'FROM', 'HOME', 'DRIVE']\n"
                                               '>>> assert all(word not in decide_commute(r[i], t[i]).upper() for i in range(len(t)) for word in not_keywords)\n',
                                       'failure_message': 'Check that your function works correctly for Walk',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> \n'
                                               ">>> keywords = ['DRIVE']\n"
                                               '>>> r = [True, False, False, True, True, True, True, False]\n'
                                               '>>> t = [40, 39, 41, 69, 70, 75, 80, 82]\n'
                                               '>>> assert all(word in decide_commute(r[i], t[i]).upper() for i in range(len(t)) for word in keywords)\n'
                                               '>>> \n'
                                               ">>> not_keywords = ['WORK', 'FROM', 'HOME', 'WALK']\n"
                                               '>>> assert all(word not in decide_commute(r[i], t[i]).upper() for i in range(len(t)) for word in not_keywords)\n',
                                       'failure_message': 'Check that your function works correctly for Drive',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
