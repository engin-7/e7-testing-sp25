OK_FORMAT = True

test = {   'name': 'q3.3',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(np.round(q3_3,10)) == '595c8e8a2c9c672204d6fa1e270139ea'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
