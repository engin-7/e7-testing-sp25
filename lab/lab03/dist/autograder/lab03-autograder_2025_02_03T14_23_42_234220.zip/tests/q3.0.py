OK_FORMAT = True

test = {   'name': 'q3.0',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check function was tested\n>>> assert get_hash(type(q3_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> g = 9.81\n'
                                               ">>> assert get_hash(round(proj_time(y0=0, v0=15, theta=40),10)) == '33eba82cf23c93006c1babc59f2fcdc4'\n"
                                               ">>> assert get_hash(round(proj_time(y0=10, v0=0, theta=45),10)) == '356cb36b68a27f68796f03a299d65bc3'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
