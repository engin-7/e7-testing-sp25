OK_FORMAT = True

test = {   'name': 'q2.3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> assert get_hash(time_array[0]) == 'cfcd208495d565ef66e7dff9f98764da' \n",
                                       'failure_message': 'Check start value of time_array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> \n>>> assert get_hash(time_array[-1]) == 'b7a782741f667201b54880c925faec4b'\n",
                                       'failure_message': 'Check final value of time_array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> \n>>> assert get_hash(np.sum(time_array)) == '39d9d6852c0ddbf22d973f6d3c72deae'\n",
                                       'failure_message': 'Check steps within time_array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               ">>> assert get_hash(round(c14frac_array[1],4)) =='ccf8e6e10af7c853137169f67a523087'\n"
                                               ">>> assert get_hash(round(c14frac_array[-1],4)) == 'e152a2147de532f22e5acd4d4b252c84'\n"
                                               ">>> assert get_hash(round(np.sum(c14frac_array),4)) == 'f82762b52fbe1dde5c5a5100ad7d2775'\n"
                                               ">>> assert get_hash(len(c14frac_array)) == '38b3eff8baf56627478ec76a704e9b52'\n",
                                       'failure_message': 'Check c14frac_array.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
