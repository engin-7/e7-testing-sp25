OK_FORMAT = True

test = {   'name': 'q2.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> assert callable(lambda_c14_dating) and lambda_c14_dating.__name__ == "<lambda>"\n',
                                       'failure_message': 'Make sure it is a lambda function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': '>>> \n'
                                               '>>> # Check function was tested\n'
                                               ">>> assert get_hash(type(q2_1)) != '14e736438b115821cbb9b7ac0ba79034'\n"
                                               '>>> assert callable(lambda_c14_dating) and lambda_c14_dating.__name__ == "<lambda>"\n',
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': ">>> assert get_hash(round(lambda_c14_dating(5730),4)) == 'd310cb367d993fb6fb584b198a2fd72c'\n"
                                               ">>> assert get_hash(round(lambda_c14_dating(0.956),4)) == '94eab0ef89d927c724320fec6169d935'\n"
                                               ">>> assert get_hash(round(lambda_c14_dating(14023),4)) == 'adc61c91420dc18855e1b8f869d62f02'\n"
                                               '>>> assert callable(lambda_c14_dating) and lambda_c14_dating.__name__ == "<lambda>"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
