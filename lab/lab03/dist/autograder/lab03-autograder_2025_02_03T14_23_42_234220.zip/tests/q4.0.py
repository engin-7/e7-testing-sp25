OK_FORMAT = True

test = {   'name': 'q4.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check function was tested\n>>> assert get_hash(type(q4_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash(round(cri_angle(f=0.1),10)) == 'f43499525a70aced5fcbc427e53ac783'\n"
                                               ">>> assert get_hash(round(cri_angle(f=0.2),10)) == '076e5dc4e59f4aedd83c15fff6bc737c'\n"
                                               ">>> assert get_hash(round(cri_angle(f=0.5),10)) == '1956b616e36ff8a16d6e7c6a24737aea'\n"
                                               ">>> assert get_hash(round(cri_angle(f=0.75),10)) == '701bf08357973b0d6a2ab8ee6f68908b'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
