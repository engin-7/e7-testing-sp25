OK_FORMAT = True

test = {   'name': 'q3.2',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(np.round(q3_2,10)) == 'de6747c71e18073a7a000b1ca5e047a0'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
