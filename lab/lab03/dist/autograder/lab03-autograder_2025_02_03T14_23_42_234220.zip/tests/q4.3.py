OK_FORMAT = True

test = {   'name': 'q4.3',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check function was tested\n>>> assert get_hash(type(q4_3)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> \n>>> # Check function returns a string\n>>> assert get_hash(type(q4_3)) == '9a86641cdf2fdb47f786dc955264738d'\n",
                                       'failure_message': 'Make sure your function returns a string!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(box_pred_any(f=0.5, theta=30)) == '7ea6c91dd27fef86440ca1c8636fb828'\n"
                                               ">>> assert get_hash(box_pred_any(f=0.25, theta=10)) == '29a5a9cb0cfe9b668420c0b73345aa7a'\n"
                                               ">>> assert get_hash(box_pred_any(f=0.75, theta=30)) == '29a5a9cb0cfe9b668420c0b73345aa7a'\n"
                                               ">>> assert get_hash(box_pred_any(f=0.35, theta=25)) == '7ea6c91dd27fef86440ca1c8636fb828'\n"
                                               ">>> assert get_hash(box_pred_any(f=1/math.sqrt(3), theta=29.999)) == '29a5a9cb0cfe9b668420c0b73345aa7a'\n"
                                               ">>> assert get_hash(box_pred_any(f=1/math.sqrt(3), theta=30.001)) == '7ea6c91dd27fef86440ca1c8636fb828'\n",
                                       'failure_message': 'Function is incorrect when both f and theta have numeric values!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> \n'
                                               ">>> keywords = ['EITHER', 'F', 'OR', 'THETA', 'SHOULD', 'NUMERIC']\n"
                                               ">>> assert all(word in box_pred_any(f='?', theta='?').upper() for word in keywords)\n",
                                       'failure_message': "Function is incorrect when both f and theta are '?'!",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': ">>> \n>>> keywords = ['IF', 'F', 'LESS', 'BOX', 'WILL', 'SLIDE']\n>>> assert all(word in box_pred_any(f='?', theta=10).upper() for word in keywords)\n",
                                       'failure_message': "Function is incorrect when f is '?'! Check the wording of the output.",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': ">>> f_cri = ['0.176', '0.466', '1.036', '3.732']\n"
                                               '>>> theta = [10, 25, 46, 75]\n'
                                               ">>> assert all(f_cri[i] in box_pred_any(f='?', theta=theta[i]) for i in range(len(theta)))\n",
                                       'failure_message': "Function is incorrect when f is '?'! Make sure you rounding the critical value to three digits after the decimal point.",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> \n'
                                               ">>> keywords = ['IF', 'THETA', 'GREATER', 'DEGREES', 'BOX', 'WILL', 'SLIDE']\n"
                                               ">>> assert all(word in box_pred_any(f=0.2, theta='?').upper() for word in keywords)\n",
                                       'failure_message': "Function is incorrect when theta is '?'! Check the wording of the output.",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> f = [0.176, 0.466, 1.036, 3.733]\n'
                                               ">>> theta_cri = ['9.982', '24.986', '46.013', '75.004']\n"
                                               ">>> assert all(theta_cri[i] in box_pred_any(f=f[i], theta='?') for i in range(len(f)))\n",
                                       'failure_message': "Function is incorrect when theta is '?'! Make sure you rounding the critical value to three digits after the decimal point.",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
