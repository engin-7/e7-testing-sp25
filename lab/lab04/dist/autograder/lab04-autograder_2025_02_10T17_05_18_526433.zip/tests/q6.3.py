OK_FORMAT = True

test = {   'name': 'q6.3',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> assert len(q6d) == 1\n>>> assert isinstance(q6d, str)\n',
                                       'failure_message': 'Incorrect answer format. Make sure you only have the letter of your answer choice in quotes.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Correct answer format. Note that the actual test is hidden.'},
                                   {'code': ">>> \n>>> assert get_hash(q6d.upper()) == '0d61f8370cad1d412f80b84d143e1257'\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
