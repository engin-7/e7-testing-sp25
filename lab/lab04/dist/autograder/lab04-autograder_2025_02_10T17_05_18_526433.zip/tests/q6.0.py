OK_FORMAT = True

test = {   'name': 'q6.0',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> assert get_hash(type(round(q6a))) == '2203e3c2293eb8c9bda5bcd97acbf884'\n",
                                       'failure_message': 'Your answer should be numeric.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {'code': ">>> assert get_hash(round(q6a)) == 'cfcd208495d565ef66e7dff9f98764da'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
