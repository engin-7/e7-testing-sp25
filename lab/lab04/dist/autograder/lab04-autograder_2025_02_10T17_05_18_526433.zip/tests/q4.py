OK_FORMAT = True

test = {   'name': 'q4',
    'points': 4,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> # Check students tested the function (type is not ellipsis)\n'
                                               '>>> assert get_hash(type(q4)) != \'14e736438b115821cbb9b7ac0ba79034\', "Make sure to test your function!"\n',
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> \n>>> # Check output structure\n>>> assert get_hash(type(Rainfall([2.3,4.1,-5.4,1.0,7.1]))) == '22b3afce62075c7012f8e5041adfee16'\n",
                                       'failure_message': 'Check output format. It should be a tuple.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> \n>>> # Check  length\n>>> assert get_hash(len(Rainfall([2.3,4.1,-5.4,1.0,7.1]))) == 'c81e728d9d4c2f636f067f89cc14862c'\n",
                                       'failure_message': 'Make sure you return both the total and average rainfall.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> \n'
                                               '>>> # Check simple case\n'
                                               ">>> assert get_hash(round(Rainfall([2.3,4.1,5.4,1.0,7.1,2,8.0,4.9,6])[0], 3)) == 'a488d325d66dc4190e9637e240990868'\n"
                                               ">>> assert get_hash(round(Rainfall([20, 3, 0, 23, 8, 7, 24, 4, 28, 17])[0], 3)) == '02522a2b2726fb0a03bb19f2d8d9524d'\n",
                                       'failure_message': 'Check rainTot',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.75},
                                   {   'code': '>>> \n'
                                               '>>> # Check simple case\n'
                                               ">>> assert get_hash(round(Rainfall([2.3,4.1,5.4,1.0,7.1,2,8.0,4.9,6])[1], 3)) == '7cc0ede3573439b052e865e1b4213db4'\n"
                                               ">>> assert get_hash(round(Rainfall([20, 3, 0, 23, 8, 7, 24, 4, 28, 17])[1], 3)) == 'dfd78eb85404bb841184ad07c266066f'\n",
                                       'failure_message': 'Check rainAvg',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.75},
                                   {   'code': '>>> \n'
                                               '>>> # Check simple case\n'
                                               ">>> assert get_hash(round(Rainfall([2.3,4.1,5.4,1.0,7.1,2,8.0,0,4.9,6])[0], 3)) == 'a488d325d66dc4190e9637e240990868'\n"
                                               ">>> assert get_hash(round(Rainfall([20, 3, 0, 23, 8, 7, 24, 4, 0, 28, 17])[0], 3)) == '02522a2b2726fb0a03bb19f2d8d9524d'\n",
                                       'failure_message': 'Check rainTot when there is a measurement equal to 0',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Check simple case\n'
                                               ">>> assert get_hash(round(Rainfall([2.3,4.1,5.4,1.0,7.1,2,8.0,0,4.9,6])[1], 3)) == '6187c0685f2fe6d1b2595c847b124663'\n"
                                               ">>> assert get_hash(round(Rainfall([20, 3, 0, 23, 8, 7, 24, 4, 0, 28, 17])[1], 3)) == 'bfd1ace15fae5dc2325cbda285874522'\n",
                                       'failure_message': 'Check rainTot when there is a measurement equal to 0',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Check negative numbers\n'
                                               ">>> assert get_hash(round(Rainfall([-2, -0.5, 1, 0, 4])[0],3)) == 'e4da3b7fbbce2345d7772b0674a318d5'\n"
                                               ">>> assert get_hash(round(Rainfall([-2, -0.5, 1, 0, 4])[1],3)) == '2280082248f35fad32c7ead135ab3f99'\n",
                                       'failure_message': 'What if the list contains negative numbers?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Check negative numbers\n'
                                               ">>> assert get_hash(round(Rainfall([-13,-19,-3,-15,7,-20,-18,13,9,17,11,0,2,-7,6,15,14])[0], 3)) == 'f4b9ec30ad9f68f89b29639786cb62ef'\n"
                                               ">>> assert get_hash(round(Rainfall([-13,-19,-3,-15,7,-20,-18,13,9,17,11,0,2,-7,6,15,14])[1], 3)) == 'b68de8f1f938e0330acdf64c63b08b9a'\n",
                                       'failure_message': 'What if the list contains negative numbers?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> \n'
                                               '>>> # Check cases with early stop\n'
                                               ">>> assert get_hash(round(Rainfall([2,1.3,-99,33,0.99,-999])[0], 3)) == '652126365f55aa7ccf24e90ed647c3a3'\n"
                                               ">>> assert get_hash(round(Rainfall([2,1.3,-99,-999,33,0.99,1])[0], 3)) == 'bca66716b9ca2d13a4c28be69b276777'\n"
                                               ">>> assert get_hash(round(Rainfall([0, -999,1.3,-99,33,0.99,-999])[0], 3)) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(round(Rainfall([2,1.3,-99,33,0.99,-999])[1], 3)) == '5cf35d410e296c02b09670b03e3d38c5'\n"
                                               ">>> assert get_hash(round(Rainfall([2,1.3,-99,-999,33,0.99,1])[1], 3)) == '448258b68b4ebf3a6590c75fca600c29'\n"
                                               ">>> assert get_hash(round(Rainfall([0, -999,1.3,-99,33,0.99,-999])[1], 3)) == '30565a8911a6bb487e3745c0ea3c8224'\n",
                                       'failure_message': 'What if the list contains -999?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
