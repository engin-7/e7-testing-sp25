OK_FORMAT = True

test = {   'name': 'q7',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> # Check students tested the function (type is not ellipsis)\n'
                                               '>>> assert get_hash(type(q7)) != \'14e736438b115821cbb9b7ac0ba79034\', "Make sure to test your function!"\n',
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check examples\n'
                                               ">>> assert get_hash(remove_vowels('Welcome to E7!')) == 'c796d49406d6eaceb4b8f0a60046d990'\n"
                                               ">>> assert get_hash(remove_vowels('Hello World!')) == '21342b09fe42a27da8720d77704ccd73'\n"
                                               ">>> assert get_hash(remove_vowels('No vowels here! Python is fun!')) == '68a087a3a7b8ff6d94aa9226b6d0f5a3'\n"
                                               ">>> assert get_hash(remove_vowels('The quick brown fox jumps over the lazy dog.')) == 'f80f4502beacd9a425caef43761e9047'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check new strings\n'
                                               ">>> assert get_hash(remove_vowels('AEIOUaeiou')) == 'd41d8cd98f00b204e9800998ecf8427e'\n"
                                               ">>> assert get_hash(remove_vowels('AEIOUaeiou! The end.')) == '9033e0e305f247c0c3c80d0c7848c8b3'\n"
                                               ">>> assert get_hash(remove_vowels('Programming is fun!!!')) == '6f721ade8c0b0f296b46a4990f94a1f6'\n"
                                               ">>> assert get_hash(remove_vowels('One two three four five')) == 'fbd35e565eb9e36330960a16c429b7d2'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
