OK_FORMAT = True

test = {   'name': 'q3',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check students tested the function (type is not ellipsis)\n>>> assert get_hash(type(q3)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> \n>>> # Check output types and length\n>>> assert get_hash(type(collatz(4))) == '22b3afce62075c7012f8e5041adfee16'\n",
                                       'failure_message': 'Check output format. It should be a tuple.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> \n>>> # Check output types and length\n>>> assert get_hash(type(collatz(4)[0])) == '425ed5b515f0a67c6316f0ec499f86bf'\n",
                                       'failure_message': 'Make sure the first returned item is a list.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> \n>>> # Check output types and length\n>>> assert get_hash(len(collatz(4))) == 'c81e728d9d4c2f636f067f89cc14862c'\n",
                                       'failure_message': 'Make sure you return both the sequence and the steps.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> \n'
                                               '>>> # Check n == 1\n'
                                               ">>> assert get_hash(int(sum(collatz(1)[0]))) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               ">>> assert get_hash(collatz(1)[1]) == 'c4ca4238a0b923820dcc509a6f75849b'\n",
                                       'failure_message': 'What if n is 1?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Check general cases\n'
                                               ">>> assert get_hash(int(sum(collatz(17)[0]))) == 'ca46c1b9512a7a8315fa3c5a946e8265'\n"
                                               ">>> assert get_hash(collatz(17)[1]) == 'c51ce410c124a10e0db5e4b97fc2af39'\n"
                                               ">>> assert get_hash(int(sum(collatz(119)[0]))) == 'e951ccd95572a67138f4572c1c7d7ee8'\n"
                                               ">>> assert get_hash(collatz(119)[1]) == 'e369853df766fa44e1ed0ff613f563bd'\n"
                                               ">>> assert get_hash(int(sum(collatz(407)[0]))) == '2af1e9eaa807096a11b32ed26ecc2cbb'\n"
                                               ">>> assert get_hash(int(sum(collatz(791)[0]))) == '3e5c39e6359d13d57826c85e119ed584'\n",
                                       'failure_message': 'Check the sequence and step count.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1.75},
                                   {   'code': '>>> \n'
                                               ">>> error_message = ['INVALID', 'INPUT']\n"
                                               '>>> # Check error message\n'
                                               ">>> assert get_hash(all([word in collatz(-1).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'What if n is negative? Check the formatting of the error message.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               ">>> error_message = ['INVALID', 'INPUT']\n"
                                               '>>> # Check error message\n'
                                               ">>> assert get_hash(all([word in collatz(0).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'What if n is zero? Check the formatting of the error message.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               ">>> error_message = ['INVALID', 'INPUT']\n"
                                               '>>> # Check error message\n'
                                               ">>> assert get_hash(all([word in collatz(8.1).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in collatz(0.5).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in collatz(1.0).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'What if n is non-integer? Check the formatting of the error message.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
