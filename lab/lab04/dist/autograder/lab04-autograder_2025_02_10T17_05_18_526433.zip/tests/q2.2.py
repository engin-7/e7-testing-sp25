OK_FORMAT = True

test = {   'name': 'q2.2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check students tested the function (type is not ellipsis)\n>>> assert get_hash(type(q2_2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Test for valid input without 0\n'
                                               ">>> assert get_hash(SumSize(14927421)) == '34173cb38f07f89ddbebc2ac9128303f'\n"
                                               ">>> assert get_hash(SumSize(1371)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(SumSize(629)) == '70efdf2ec9b086079795c442636b55fb'\n"
                                               ">>> assert get_hash(SumSize(104927421)) == '34173cb38f07f89ddbebc2ac9128303f'\n"
                                               ">>> assert get_hash(SumSize(13710)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(SumSize(60020090)) == '70efdf2ec9b086079795c442636b55fb'\n",
                                       'failure_message': 'Make sure the default value of size is set to 1',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               ">>> assert get_hash(SumSize(14927421,2)) == '757b505cfd34c64c85ca5b5690ee5293'\n"
                                               ">>> assert get_hash(SumSize(1371,2)) == '68d30a9594728bc39aa24be94b319d21'\n"
                                               ">>> assert get_hash(SumSize(629,3)) == '051e4e127b92f5d98d3c79b195f2b291'\n"
                                               ">>> assert get_hash(SumSize(10492742,4)) == '690bb330e5e7e3e07867fafc4d32ec82'\n"
                                               ">>> assert get_hash(SumSize(600200900,3)) == '01e00f2f4bfcbb7505cb641066f2859b'\n",
                                       'failure_message': 'Make sure the function works for any value of size',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> \n'
                                               ">>> error_message = ['NUMBER', 'DIGITS', 'N', 'SHOULD', 'MULTIPLE', 'SIZE']\n"
                                               '>>> assert all([word in SumSize(1,3).upper() for word in error_message])\n'
                                               '>>> assert all([word in SumSize(1,2).upper() for word in error_message])\n'
                                               '>>> assert all([word in SumSize(12345,3).upper() for word in error_message])\n'
                                               '>>> assert all([word in SumSize(15487411,6).upper() for word in error_message])\n',
                                       'failure_message': 'What if the number of digits in n is not a multiple of size?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
