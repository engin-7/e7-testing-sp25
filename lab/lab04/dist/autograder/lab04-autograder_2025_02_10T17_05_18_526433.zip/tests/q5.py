OK_FORMAT = True

test = {   'name': 'q5',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check students tested the function (type is not ellipsis)\n>>> assert get_hash(type(q5)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> import inspect\n'
                                               ">>> assert any([True if GenRec.__name__ in line and '(' in line else False for line in inspect.getsourcelines(GenRec)[0][1:]])\n"
                                               ">>> assert all([False if 'for' in line else True for line in inspect.getsourcelines(GenRec)[0][1:]])\n"
                                               ">>> assert all([False if 'while' in line else True for line in inspect.getsourcelines(GenRec)[0][1:]])\n",
                                       'failure_message': 'Your function should use recursion! for and while keywords are not allowed in the function (not even in comments)',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> \n'
                                               '>>> import inspect\n'
                                               ">>> assert any([True if GenRec.__name__ in line and '(' in line else False for line in inspect.getsourcelines(GenRec)[0][1:]])\n"
                                               ">>> assert all([False if 'for' in line else True for line in inspect.getsourcelines(GenRec)[0][1:]])\n"
                                               ">>> assert all([False if 'while' in line else True for line in inspect.getsourcelines(GenRec)[0][1:]])\n"
                                               '>>> \n'
                                               '>>> # Test base-cases\n'
                                               ">>> assert get_hash(GenRec(2, 4, 0, 2, 0)) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(GenRec(2, 4, 1, 2, 0)) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               ">>> assert get_hash(GenRec(4, 2, 2, 1, 0)) == 'c81e728d9d4c2f636f067f89cc14862c'\n",
                                       'failure_message': 'Check the base case for n=0',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> \n'
                                               '>>> import inspect\n'
                                               ">>> assert any([True if GenRec.__name__ in line and '(' in line else False for line in inspect.getsourcelines(GenRec)[0][1:]])\n"
                                               ">>> assert all([False if 'for' in line else True for line in inspect.getsourcelines(GenRec)[0][1:]])\n"
                                               ">>> assert all([False if 'while' in line else True for line in inspect.getsourcelines(GenRec)[0][1:]])\n"
                                               '>>> \n'
                                               '>>> # Test base-cases\n'
                                               ">>> assert get_hash(GenRec(4, 3, 0, 2, 1)) == 'c81e728d9d4c2f636f067f89cc14862c'\n"
                                               ">>> assert get_hash(GenRec(5, 1, 1, 3, 1)) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n"
                                               ">>> assert get_hash(GenRec(0, 1, 2, 1, 1)) == 'c4ca4238a0b923820dcc509a6f75849b'\n",
                                       'failure_message': 'Check the base case for n=1',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> \n'
                                               '>>> import inspect\n'
                                               ">>> assert any([True if GenRec.__name__ in line and '(' in line else False for line in inspect.getsourcelines(GenRec)[0][1:]])\n"
                                               ">>> assert all([False if 'for' in line else True for line in inspect.getsourcelines(GenRec)[0][1:]])\n"
                                               ">>> assert all([False if 'while' in line else True for line in inspect.getsourcelines(GenRec)[0][1:]])\n"
                                               '>>> \n'
                                               '>>> # Test for valid input n > 2\n'
                                               ">>> assert get_hash(GenRec(4, 3, 0, 2, 5)) == 'f0adc8838f4bdedde4ec2cfad0515589'\n"
                                               ">>> assert get_hash(GenRec(4, 3, 1, 2, 5)) == '818f4654ed39a1c147d1e51a00ffb4cb'\n"
                                               ">>> assert get_hash(GenRec(1, 2, 0, 0, 5)) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(GenRec(0, 0, 1, 5, 10)) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(GenRec(1, 1, 1, 5, 10)) == 'eddea82ad2755b24c4e168c5fc2ebd40'\n"
                                               ">>> assert get_hash(GenRec(1, 2, 1, 5, 25)) == '6938db3189d0daee0bd06d4d54429da4'\n",
                                       'failure_message': 'Check the general case',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1.75}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
