OK_FORMAT = True

test = {   'name': 'q6.4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> # Test base-cases\n'
                                               ">>> assert get_hash(kbonacci(0,2)) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(kbonacci(0,3)) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(kbonacci(1,4)) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(kbonacci(2,5)) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(kbonacci(3,5)) == 'cfcd208495d565ef66e7dff9f98764da'\n",
                                       'failure_message': 'Check the base case',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Test base-cases\n'
                                               ">>> assert get_hash(kbonacci(1,2)) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               ">>> assert get_hash(kbonacci(2,3)) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               ">>> assert get_hash(kbonacci(3,4)) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               ">>> assert get_hash(kbonacci(4,5)) == 'c4ca4238a0b923820dcc509a6f75849b'\n",
                                       'failure_message': 'Check the base case',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               ">>> assert get_hash(kbonacci(5,2)) == 'e4da3b7fbbce2345d7772b0674a318d5'\n"
                                               ">>> assert get_hash(kbonacci(10,2)) == 'b53b3a3d6ab90ce0268229151c9bde11'\n"
                                               ">>> assert get_hash(kbonacci(10,3)) == '43ec517d68b6edd3015b3edc9a11367b'\n"
                                               ">>> assert get_hash(kbonacci(10,4)) == '9f61408e3afb633e50cdf1b20de6f466'\n"
                                               ">>> assert get_hash(kbonacci(5,3)) == 'a87ff679a2f3e71d9181a67b7542122c'\n"
                                               ">>> assert get_hash(kbonacci(4,4)) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               ">>> assert get_hash(kbonacci(15,5)) == '2a9d121cd9c3a1832bb6d2cc6bd7a8a7'\n"
                                               ">>> assert get_hash(kbonacci(14,6)) == '621bf66ddb7c962aa0d22ac97d69b793'\n",
                                       'failure_message': 'Check the general case',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
