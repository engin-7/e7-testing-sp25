OK_FORMAT = True

test = {   'name': 'q6.2',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> assert len(q6c) == 1\n>>> assert isinstance(q6c, str)\n',
                                       'failure_message': 'Incorrect answer format. Make sure you only have the letter of your answer choice in quotes.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Correct answer format. Note that the actual test is hidden.'},
                                   {'code': ">>> \n>>> assert get_hash(q6c.upper()) == 'f623e75af30e62bbd73d6df5b50bb7b5'\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
