OK_FORMAT = True

test = {   'name': 'q8',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> # Check students tested the function (type is not ellipsis)\n'
                                               '>>> assert get_hash(type(q8)) != \'14e736438b115821cbb9b7ac0ba79034\', "Make sure to test your function!"\n',
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               '>>> # Check data structure\n'
                                               ">>> assert get_hash(type(mySummation([1, 1, 5, 6, 7, 8, 10],10))) == '30b39aca73d0815f5ca1a06af1412947'\n"
                                               ">>> assert get_hash(mySummation([1, 1, 5, 6, 7, 8, 10],10).shape) == '0f6c6ad8083308c6c59c917667b3fa2f'\n",
                                       'failure_message': 'Check output type.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               '>>> # Check data structure\n'
                                               ">>> assert get_hash(type(mySummation([1, 1, 5, 6, 7, 8, 10],10))) == '30b39aca73d0815f5ca1a06af1412947'\n"
                                               ">>> assert get_hash(mySummation([1, 1, 5, 6, 7, 8, 10],10).shape) == '0f6c6ad8083308c6c59c917667b3fa2f'\n",
                                       'failure_message': 'Check output shape.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               '>>> # Check empty cases\n'
                                               ">>> assert get_hash(mySummation([0, 1, 1, 2, 3, 4],10)) == 'd751713988987e9331980363e24189ce'\n"
                                               ">>> assert get_hash(mySummation([10,20,30,40,50],200)) == 'd751713988987e9331980363e24189ce'\n",
                                       'failure_message': 'What if no three elements add up to sumTarget?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> \n>>> assert get_hash(mySummation([10,0,1,2],21)) == 'd751713988987e9331980363e24189ce'\n",
                                       'failure_message': 'Make sure to not select an element more than once.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               '>>> # Check simple case\n'
                                               ">>> assert get_hash(mySummation([2,3,4,5,6],12).shape) == '590392f0cb88f1eb89930f4de5e9eaaa'\n"
                                               ">>> assert get_hash(int(sum(mySummation([2,3,4,5,6],12)[:,2]))) == '6512bd43d9caa6e02c990b0a82652dca'\n",
                                       'failure_message': 'Make sure your rows are sorted.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               '>>> # Check case with multiple occurence\n'
                                               ">>> assert get_hash(int(sum(mySummation([0, 0, 2, 4, 6, 8, 14],14)[:,2]))) == '34173cb38f07f89ddbebc2ac9128303f'\n"
                                               '>>> assert get_hash(int(sum(mySummation([1,5,6,5,1],12)[:,2])))\n',
                                       'failure_message': 'Make sure all rows are unique.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               '>>> # Check random case \n'
                                               '>>> arr = [3, -4, 2, -2, -7, -10, 4, 5, 8, 6, 7, -6]\n'
                                               ">>> assert get_hash(int(sum(mySummation(arr,10)[:,2]))) == '33e75ff09dd601bbe69f351039152189'\n"
                                               '>>> arr = [9, 4, 5, -4, 2, -6, 7, -9, 8, -7, 1, -2]\n'
                                               ">>> assert get_hash(int(sum(mySummation(arr,10)[:,2]))) == 'a684eceee76fc522773286a895bc8436'\n",
                                       'failure_message': 'Make sure all rows are unique.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
