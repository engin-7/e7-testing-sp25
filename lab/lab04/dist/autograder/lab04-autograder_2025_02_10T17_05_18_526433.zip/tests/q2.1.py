OK_FORMAT = True

test = {   'name': 'q2.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check students tested the function (type is not ellipsis)\n>>> assert get_hash(type(q2_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> \n'
                                               '>>> assert callable(lambdaSum) and lambdaSum.__name__ == "<lambda>"\n'
                                               '>>> \n'
                                               '>>> # Check if Sum() is being called inside lambdaSum()\n'
                                               '>>> Sum_temp = Sum\n'
                                               '>>> try:\n'
                                               '...     Sum = sum # modify Sum\n'
                                               '...     assert lambdaSum(10) == 1\n'
                                               '... except TypeError:\n'
                                               '...     Sum = Sum_temp\n'
                                               '...     assert 0 == 1\n'
                                               '>>> Sum = Sum_temp\n',
                                       'failure_message': 'Make sure it is a lambda function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> \n'
                                               '>>> # Test for valid input without 0\n'
                                               ">>> assert get_hash(lambdaSum(14927421)) == '34173cb38f07f89ddbebc2ac9128303f'\n"
                                               ">>> assert get_hash(lambdaSum(1371)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(lambdaSum(629)) == '70efdf2ec9b086079795c442636b55fb'\n"
                                               '>>> assert callable(Sum) and lambdaSum.__name__ == "<lambda>"\n',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Test for valid input with 0\n'
                                               ">>> assert get_hash(lambdaSum(104927421)) == '34173cb38f07f89ddbebc2ac9128303f'\n"
                                               ">>> assert get_hash(lambdaSum(13710)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(lambdaSum(60020090)) == '70efdf2ec9b086079795c442636b55fb'\n"
                                               '>>> assert callable(Sum) and lambdaSum.__name__ == "<lambda>"\n',
                                       'failure_message': 'What if n has 0?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               ">>> error_message = ['INVALID', 'INPUT']\n"
                                               '>>> # Test for non-integer (use .upper() to avoid failed test due to upper/lower case)\n'
                                               ">>> assert get_hash(all([word in lambdaSum(0.1).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in lambdaSum(10.1).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in lambdaSum(10.00000001).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in lambdaSum(10.9).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in lambdaSum(10.0).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               '>>> assert callable(Sum) and lambdaSum.__name__ == "<lambda>"\n',
                                       'failure_message': 'What if n is non-integer?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               ">>> error_message = ['INVALID', 'INPUT']\n"
                                               '>>> # Test for negative values (use .upper() to avoid failed test due to upper/lower case)\n'
                                               ">>> assert get_hash(all([word in lambdaSum(-1).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in lambdaSum(-99).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in lambdaSum(-0.01).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               '>>> assert callable(Sum) and lambdaSum.__name__ == "<lambda>"\n',
                                       'failure_message': 'What if n is negative?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
