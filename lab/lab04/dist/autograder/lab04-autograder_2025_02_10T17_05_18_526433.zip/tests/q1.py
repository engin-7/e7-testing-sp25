OK_FORMAT = True

test = {   'name': 'q1',
    'points': 4,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check students tested the function (type is not ellipsis)\n>>> assert get_hash(type(q1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> \n>>> # Check return value type\n>>> assert get_hash(type(mySavingsPlan(1000, 0.05, 10000))) == '2203e3c2293eb8c9bda5bcd97acbf884'\n",
                                       'failure_message': 'Make sure your function returns an integer.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Check simple cases\n'
                                               ">>> assert get_hash(mySavingsPlan(1000, 0.05, 10000)) == '642e92efb79421734881b53e1e1b18b6'\n"
                                               ">>> assert get_hash(mySavingsPlan(2000, 0.15, 10000)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(mySavingsPlan(500, 0.4, 5000)) == '8f14e45fceea167a5a36dedd4bea2543'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1.5},
                                   {   'code': ">>> \n>>> # Check P0 > goal \n>>> assert get_hash(mySavingsPlan(4000, 0.10, 300)) == 'cfcd208495d565ef66e7dff9f98764da'\n",
                                       'failure_message': 'What if P0 is greater than the goal? Are additional years needed for saving?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': ">>> \n>>> # Check P0 == goal\n>>> assert get_hash(mySavingsPlan(300, 0.10, 300)) == 'cfcd208495d565ef66e7dff9f98764da'\n",
                                       'failure_message': 'What if P0 is equal to the goal? Are additional years needed for saving?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
