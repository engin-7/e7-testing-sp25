OK_FORMAT = True

test = {   'name': 'q1.0',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check students tested the function (type is not ellipsis)\n>>> assert get_hash(type(q1_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               ">>> error_message = ['N', 'MUST', 'NON-NEGATIVE','INTEGER']\n"
                                               '>>> # Test for negative and non-intger\n'
                                               '>>> random.seed(7) # specify seed so that all tests are based on the same numbers\n'
                                               '>>> for i in range (100): # test 100 randomly generated numbers\n'
                                               '...     assert get_hash(all([word in FibRec(random.uniform(-100, -0.0001)).upper() for word in error_message])) == '
                                               "'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'What if n is negative and non-integer?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               ">>> error_message = ['N', 'MUST', 'NON-NEGATIVE','INTEGER']\n"
                                               '>>> # Test for negative only\n'
                                               '>>> random.seed(7) # specify seed so that all tests are based on the same numbers\n'
                                               '>>> for i in range (100): # test 100 randomly generated numbers\n'
                                               "...     assert get_hash(all([word in FibRec(random.uniform(-100, -1)).upper() for word in error_message])) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'What if n is negative?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               ">>> error_message = ['N', 'MUST', 'NON-NEGATIVE','INTEGER']\n"
                                               '>>> # Test for non-integer only\n'
                                               '>>> random.seed(7) # specify seed so that all tests are based on the same numbers\n'
                                               '>>> for i in range (100): # test 100 randomly generated numbers\n'
                                               '...     assert all([word in FibRec(random.uniform(0.0001, 100)).upper() for word in error_message])\n'
                                               '>>> assert all([word in FibRec(10.).upper() for word in error_message])    \n',
                                       'failure_message': 'What if n is non-integer?',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> import inspect\n'
                                               ">>> assert any([True if FibRec.__name__ in line and '(' in line else False for line in inspect.getsourcelines(FibRec)[0][1:]])\n"
                                               ">>> assert all([False if 'for' in line else True for line in inspect.getsourcelines(FibRec)[0][1:]])\n"
                                               ">>> assert all([False if 'while' in line else True for line in inspect.getsourcelines(FibRec)[0][1:]])\n",
                                       'failure_message': 'Your function should use recursion! for and while keywords are not allowed in the function (not even in comments)',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> \n'
                                               '>>> # Test base-cases\n'
                                               ">>> assert get_hash(round(FibRec(0),5)) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(round(FibRec(1),5)) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               '>>> \n'
                                               '>>> import inspect\n'
                                               ">>> assert any([True if FibRec.__name__ in line and '(' in line else False for line in inspect.getsourcelines(FibRec)[0][1:]])\n"
                                               ">>> assert all([False if 'for' in line else True for line in inspect.getsourcelines(FibRec)[0][1:]])\n"
                                               ">>> assert all([False if 'while' in line else True for line in inspect.getsourcelines(FibRec)[0][1:]])\n",
                                       'failure_message': 'Check the base cases',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> \n'
                                               '>>> # Test for valid input n > 2\n'
                                               ">>> assert get_hash(round(FibRec(29),5)) == 'e26c8b70a0ac4b4fbb6e9579136338e7'\n"
                                               ">>> assert get_hash(round(FibRec(2),5)) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               ">>> assert get_hash(round(FibRec(3),5)) == 'c81e728d9d4c2f636f067f89cc14862c'\n"
                                               ">>> assert get_hash(round(FibRec(4),5)) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n"
                                               ">>> assert get_hash(round(FibRec(5),5)) == 'e4da3b7fbbce2345d7772b0674a318d5'\n"
                                               '>>> \n'
                                               '>>> import inspect\n'
                                               ">>> assert any([True if FibRec.__name__ in line and '(' in line else False for line in inspect.getsourcelines(FibRec)[0][1:]])\n"
                                               ">>> assert all([False if 'for' in line else True for line in inspect.getsourcelines(FibRec)[0][1:]])\n"
                                               ">>> assert all([False if 'while' in line else True for line in inspect.getsourcelines(FibRec)[0][1:]])\n",
                                       'failure_message': 'Check the general case',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
