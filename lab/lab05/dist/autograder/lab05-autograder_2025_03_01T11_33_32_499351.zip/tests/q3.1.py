OK_FORMAT = True

test = {   'name': 'q3.1',
    'points': 7,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> # Check students tested the function (type is not ellipsis)\n'
                                               '>>> assert get_hash(type(q3_1)) != \'14e736438b115821cbb9b7ac0ba79034\', "Make sure to test your function!"\n',
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Test general case\n'
                                               ">>> assert get_hash(round(Single2Decimal('10111110000101010101110101100101'),15)) == '23739091b887b8f9fc4c9fe4e02436b2' \n"
                                               ">>> assert get_hash(round(Single2Decimal('10111110010101010101010101010101'),15)) == '9f60bfac8758d685ffd2e316ce568f7c'\n"
                                               ">>> assert get_hash(round(Single2Decimal('10111110001010101010101010101010'),15)) == 'cdef8ac4c13a0ae15e0fd43092e87dcb' \n"
                                               ">>> assert get_hash(round(Single2Decimal('00111110010101010101010101010101'),15)) == '7d3a7c924518ecd45ba72d83c1150478'\n"
                                               ">>> assert get_hash(round(Single2Decimal('00111110011111111111111111111111'),15)) == 'b3b8565ff58ee0679dbda39277f1274f'\n"
                                               ">>> assert get_hash(round(Single2Decimal('10111110000000000000000000000000'),15)) == 'f4ad12ca28d7185d06e97196e2e1cf36' \n"
                                               ">>> assert get_hash(round(float(Single2Decimal('11111111000000000000000000000000')),15)) == '0df947f284405c162ee14421cd47f061'\n"
                                               ">>> assert get_hash(round(float(Single2Decimal('01111111000000000000000000000000')),15)) == 'e8774d69bf49c6173d037382f2b2a748'\n"
                                               ">>> assert get_hash(round(float(Single2Decimal('00111111100000000000000000000000')),15)) == 'e4c2e8edac362acab7123654b9e73432'\n"
                                               ">>> assert get_hash(round(Single2Decimal('00111111111111111111111111111111'),15)) == '24570d1da2ec0afc011253668e27af0d'\n"
                                               ">>> assert get_hash(round(float(Single2Decimal('01010101000000000000000000000000')),15)) == '08a104b5fcc816f3500f32d0892440e2'\n"
                                               ">>> assert get_hash(round(Single2Decimal('00101010100000000000000000000000'),15)) == '7b5090a6b0a72cb37ff7d77629cfab32'\n",
                                       'failure_message': 'Check the general equation when e!=0 and e!=255.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 3.75},
                                   {   'code': '>>> \n'
                                               '>>> # Test 0\n'
                                               ">>> assert get_hash(float(Single2Decimal('10000000000000000000000000000000'))) == '30565a8911a6bb487e3745c0ea3c8224'\n"
                                               ">>> assert get_hash(float(Single2Decimal('00000000000000000000000000000000'))) == '30565a8911a6bb487e3745c0ea3c8224'\n",
                                       'failure_message': 'Check when e=0 and f=0.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> \n'
                                               '>>> # Test inf\n'
                                               ">>> assert get_hash(Single2Decimal('11111111100000000000000000000000')) == '9c41dab8e025b5db402b00cface5d381'\n"
                                               ">>> assert get_hash(Single2Decimal('01111111100000000000000000000000')) == 'ee7b630995e7a36b6420696989441e2d'\n",
                                       'failure_message': 'Check when e=255 and f=0.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> \n'
                                               '>>> # Test NaN\n'
                                               ">>> assert get_hash(Single2Decimal('11111111100000000000000000000001')) == 'a3d2de7675556553a5f08e4c88d2c228'\n"
                                               ">>> assert get_hash(Single2Decimal('01111111100000000000000000000001')) == 'a3d2de7675556553a5f08e4c88d2c228'\n"
                                               ">>> assert get_hash(Single2Decimal('11111111100110010000010000010001')) == 'a3d2de7675556553a5f08e4c88d2c228'\n",
                                       'failure_message': 'Check when e=255 and f!=0.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> \n'
                                               '>>> # Test Denormalized \n'
                                               ">>> assert get_hash(round(math.log(Single2Decimal('00000000011101010101110101100101')))) == '3bc0d1e12f5876caa954e3abf1fd85ac'\n"
                                               ">>> assert get_hash(round(Single2Decimal('00000000011101010101110101100101')\\\n"
                                               "...       /10**(round(math.log10(Single2Decimal('00000000011101010101110101100101')))),15)) == '678c1ce283c6ffd2588c31c49d565873'\n",
                                       'failure_message': 'Check order of magnitude when e=0 and f!=0',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1.5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
