OK_FORMAT = True

test = {   'name': 'q1.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check students tested the function (type is not ellipsis)\n>>> assert get_hash(type(q1_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> # Test for valid input n > 2\n'
                                               ">>> assert get_hash(round(simpleFibRatio(29),5)) == '57662aaff0603ba873d19444ae440a49'\n"
                                               ">>> assert get_hash(round(simpleFibRatio(2),5)) == 'e4c2e8edac362acab7123654b9e73432'\n"
                                               ">>> assert get_hash(round(simpleFibRatio(3),5)) == 'd1bd83a33f1a841ab7fda32449746cc4'\n"
                                               ">>> assert get_hash(round(simpleFibRatio(4),5)) == '6008647277c4454cecd97d33c069f0ca'\n"
                                               ">>> assert get_hash(round(simpleFibRatio(5),5)) == '95df9c10da10397475f9b1897410e091'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               '>>> # Test for invalid inputs and make sure an error is raised\n'
                                               '>>> try:\n'
                                               '...     simpleFibRatio(1)\n'
                                               "...     assert get_hash(2) == 'c4ca4238a0b923820dcc509a6f75849b' # assert fails\n"
                                               '... except ZeroDivisionError:\n'
                                               "...     assert get_hash(1) == 'c4ca4238a0b923820dcc509a6f75849b' # assert passes\n",
                                       'failure_message': 'You should not handle any exceptions.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
