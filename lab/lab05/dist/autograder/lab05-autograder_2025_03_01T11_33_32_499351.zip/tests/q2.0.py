OK_FORMAT = True

test = {   'name': 'q2.0',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check students tested the function (type is not ellipsis)\n>>> assert get_hash(type(q2_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> import inspect\n'
                                               ">>> assert all([False if 'int(binary, 2)' in line else True for line in inspect.getsourcelines(Binary2Num)[0][1:]])\n"
                                               ">>> assert all([False if 'int(binary' in line else True for line in inspect.getsourcelines(Binary2Num)[0][1:]])\n"
                                               ">>> assert all([False if 'int( binary' in line else True for line in inspect.getsourcelines(Binary2Num)[0][1:]])\n",
                                       'failure_message': 'Do not use built-in functions that converts from binary to decimal (not even in the comments)',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> \n'
                                               ">>> error_message = ['BINARY','STRING','LENGTH','8','MADE','ONLY','0','1']\n"
                                               '>>> # Test argument binary\n'
                                               ">>> assert get_hash(all([word in Binary2Num(binary='',representation='Sign').upper() for word in error_message])) == "
                                               "'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Binary2Num(binary='100000011',representation='Sign').upper() for word in error_message])) == "
                                               "'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Binary2Num(binary='10000001 ',representation='Sign').upper() for word in error_message])) == "
                                               "'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Binary2Num(binary='1000000a',representation='Sign').upper() for word in error_message])) == "
                                               "'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Binary2Num(binary='100.0001',representation='Sign').upper() for word in error_message])) == "
                                               "'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'Check invalid binary input message.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> \n'
                                               ">>> error_message = ['INVALID','REPRESENTATION']\n"
                                               '>>> # Test argument representation\n'
                                               ">>> assert get_hash(all([word in Binary2Num(binary='10000001', representation='').upper() for word in error_message])) == "
                                               "'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Binary2Num(binary='10000001', representation='sign').upper() for word in error_message])) == "
                                               "'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Binary2Num(binary='10000001', representation='un').upper() for word in error_message])) == "
                                               "'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(all([word in Binary2Num(binary='10000001', representation='TC ').upper() for word in error_message])) == "
                                               "'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'Check invalid repesentation message.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': '>>> \n'
                                               ">>> error_message = ['BINARY','STRING','LENGTH','8','MADE','ONLY','0','1']\n"
                                               '>>> # Test arguments binary and representation\n'
                                               ">>> assert get_hash(all([word in Binary2Num(binary='100000011',representation='').upper() for word in error_message])) == "
                                               "'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'Check invalid binary input message. You should check binary first and then repesentation.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Test UnSign\n'
                                               ">>> assert get_hash(int(Binary2Num(binary='10000001',representation='UnSign'))) == 'd1f491a404d6854880943e5c3cd9ca25'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='11111111',representation='UnSign'))) == 'fe131d7f5a6b38b23cc967316c13dae2'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='00000000',representation='UnSign'))) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='01111110',representation='UnSign'))) == '069059b7ef840f0c74a814ec9237b6ec'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='01010101',representation='UnSign'))) == '3ef815416f775098fe977004015c6193'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='10101010',representation='UnSign'))) == '149e9677a5989fd342ae44213df68868'\n"
                                               '>>> \n'
                                               '>>> import inspect\n'
                                               ">>> assert all([False if 'int(binary, 2)' in line else True for line in inspect.getsourcelines(Binary2Num)[0][1:]])\n"
                                               ">>> assert all([False if 'int(binary' in line else True for line in inspect.getsourcelines(Binary2Num)[0][1:]])\n"
                                               ">>> assert all([False if 'int( binary' in line else True for line in inspect.getsourcelines(Binary2Num)[0][1:]])\n",
                                       'failure_message': 'Check the UnSign representation.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> \n'
                                               '>>> # Test Sign\n'
                                               ">>> assert get_hash(int(Binary2Num(binary='10000001',representation='Sign'))) == '6bb61e3b7bce0931da574d19d1d82c88'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='11111111',representation='Sign'))) == '21b1992fa1b053b03c6b149ef2d9a8a8'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='00000000',representation='Sign'))) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='01111110',representation='Sign'))) == '069059b7ef840f0c74a814ec9237b6ec'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='01010101',representation='Sign'))) == '3ef815416f775098fe977004015c6193'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='10101010',representation='Sign'))) == '8dfcb89fd8620e3e7fb6a03a53f307dc'\n"
                                               '>>> \n'
                                               '>>> import inspect\n'
                                               ">>> assert all([False if 'int(binary, 2)' in line else True for line in inspect.getsourcelines(Binary2Num)[0][1:]])\n"
                                               ">>> assert all([False if 'int(binary' in line else True for line in inspect.getsourcelines(Binary2Num)[0][1:]])\n"
                                               ">>> assert all([False if 'int( binary' in line else True for line in inspect.getsourcelines(Binary2Num)[0][1:]])\n",
                                       'failure_message': 'Check the Sign representation.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': ">>> \n>>> # Test Sign\n>>> assert get_hash(int(Binary2Num(binary='10000000',representation='Sign'))) == 'bb8a6de218bc9d8045e4cc5f62d7c32d'\n",
                                       'failure_message': 'For Sign representation, 10000000 represents -128',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Test TC\n'
                                               ">>> assert get_hash(int(Binary2Num(binary='10000001',representation='TC'))) == '21b1992fa1b053b03c6b149ef2d9a8a8'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='11111111',representation='TC'))) == '6bb61e3b7bce0931da574d19d1d82c88'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='00000000',representation='TC'))) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='01111110',representation='TC'))) == '069059b7ef840f0c74a814ec9237b6ec'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='01010101',representation='TC'))) == '3ef815416f775098fe977004015c6193'\n"
                                               ">>> assert get_hash(int(Binary2Num(binary='10101010',representation='TC'))) == 'aa21e5886910db5cf181502a9dabc5ac'\n"
                                               '>>> \n'
                                               '>>> import inspect\n'
                                               ">>> assert all([False if 'int(binary, 2)' in line else True for line in inspect.getsourcelines(Binary2Num)[0][1:]])\n"
                                               ">>> assert all([False if 'int(binary' in line else True for line in inspect.getsourcelines(Binary2Num)[0][1:]])\n"
                                               ">>> assert all([False if 'int( binary' in line else True for line in inspect.getsourcelines(Binary2Num)[0][1:]])\n",
                                       'failure_message': 'Check the TC representation.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1.25}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
