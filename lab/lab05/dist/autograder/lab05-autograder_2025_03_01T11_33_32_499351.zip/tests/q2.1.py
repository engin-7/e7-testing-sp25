OK_FORMAT = True

test = {   'name': 'q2.1',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check students tested the function (type is not ellipsis)\n>>> assert get_hash(type(q2_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> \n'
                                               '>>> # Test UnSign\n'
                                               ">>> assert get_hash(int(BinaryComplement(binary='10000001',representation='UnSign'))) == '069059b7ef840f0c74a814ec9237b6ec'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='11111111',representation='UnSign'))) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='00000000',representation='UnSign'))) == 'fe131d7f5a6b38b23cc967316c13dae2'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='01111110',representation='UnSign'))) == 'd1f491a404d6854880943e5c3cd9ca25'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='01010101',representation='UnSign'))) == '149e9677a5989fd342ae44213df68868'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='10101010',representation='UnSign'))) == '3ef815416f775098fe977004015c6193'\n",
                                       'failure_message': 'Make sure you are getting the complement correctly. Also, check the UnSign representation.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> \n'
                                               '>>> # Test Sign\n'
                                               ">>> assert get_hash(int(BinaryComplement(binary='10000001',representation='Sign'))) == '069059b7ef840f0c74a814ec9237b6ec'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='11111111',representation='Sign'))) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='00000000',representation='Sign'))) == '21b1992fa1b053b03c6b149ef2d9a8a8'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='01111110',representation='Sign'))) == '6bb61e3b7bce0931da574d19d1d82c88'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='01010101',representation='Sign'))) == '8dfcb89fd8620e3e7fb6a03a53f307dc'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='10101010',representation='Sign'))) == '3ef815416f775098fe977004015c6193'\n",
                                       'failure_message': 'Make sure you are getting the complement correctly. Also, check the Sign representation.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.75},
                                   {   'code': ">>> \n>>> # Test Sign\n>>> assert get_hash(int(BinaryComplement(binary='01111111',representation='Sign'))) == 'bb8a6de218bc9d8045e4cc5f62d7c32d'\n",
                                       'failure_message': 'For Sign representation, 10000000 represents -128',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Test TC\n'
                                               ">>> assert get_hash(int(BinaryComplement(binary='01111110',representation='TC'))) == '21b1992fa1b053b03c6b149ef2d9a8a8'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='00000000',representation='TC'))) == '6bb61e3b7bce0931da574d19d1d82c88'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='11111111',representation='TC'))) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='10000001',representation='TC'))) == '069059b7ef840f0c74a814ec9237b6ec'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='10101010',representation='TC'))) == '3ef815416f775098fe977004015c6193'\n"
                                               ">>> assert get_hash(int(BinaryComplement(binary='01010101',representation='TC'))) == 'aa21e5886910db5cf181502a9dabc5ac'\n",
                                       'failure_message': 'Make sure you are getting the complement correctly. Also, check the TC representation.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
