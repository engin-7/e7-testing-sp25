OK_FORMAT = True

test = {   'name': 'q1.4',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> assert len(q1_4) == 1\n>>> assert isinstance(q1_4, str)\n',
                                       'failure_message': 'Incorrect answer format. Make sure you only have the letter of your answer choice in quotes.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Correct answer format. Note that the actual test is hidden.'},
                                   {'code': ">>> \n>>> assert get_hash(q1_4.upper()) == 'dfcf28d0734569a6a693bc8194de62bf'\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
