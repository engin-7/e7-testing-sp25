OK_FORMAT = True

test = {   'name': 'q3.0',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check students tested the function (type is not ellipsis)\n>>> assert get_hash(type(q3_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Test formatting of output\n'
                                               ">>> assert get_hash(type(CompareFloats(0,0,0))) == '22b3afce62075c7012f8e5041adfee16'\n"
                                               ">>> assert get_hash(type(CompareFloats(0,0,0)[0])) == '781f5f2052cfb496fa73d70ea1fbdaa8'\n"
                                               ">>> assert get_hash(type(CompareFloats(0,0,0)[1])) == '781f5f2052cfb496fa73d70ea1fbdaa8'\n",
                                       'failure_message': 'Check output format. The output should be a tuple of two boolean values.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> \n'
                                               '>>> # Test exact\n'
                                               ">>> assert get_hash(CompareFloats(x=1,y=1,tol=1e-3)[0]) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(CompareFloats(x=1,y=2,tol=1e-3)[0]) == 'f8320b26d30ab433c5a54546d21f414c'\n"
                                               ">>> assert get_hash(CompareFloats(x=0+5,y=5,tol=1e-3)[0]) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'Check exact comparison.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.75},
                                   {   'code': '>>> \n'
                                               '>>> # Test approx\n'
                                               ">>> assert get_hash(CompareFloats(x=1,y=1,tol=1e-3)[1]) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(CompareFloats(x=1,y=2,tol=1e-3)[1]) == 'f8320b26d30ab433c5a54546d21f414c'\n"
                                               ">>> assert get_hash(CompareFloats(x=1e-4,y=1e-5,tol=1e-4)[1]) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(CompareFloats(x=1e-4,y=1e-5,tol=1e-5)[1]) == 'f8320b26d30ab433c5a54546d21f414c'\n"
                                               ">>> assert get_hash(CompareFloats(x=-1e-4,y=0,tol=1e-4)[1]) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(CompareFloats(x=-1e-4,y=0,tol=1e-5)[1]) == 'f8320b26d30ab433c5a54546d21f414c'\n",
                                       'failure_message': 'Check approximate comparison.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1.5},
                                   {   'code': '>>> \n'
                                               '>>> # Tests default values and variable names\n'
                                               ">>> assert get_hash(CompareFloats(1e-8,1.1e-8)[1]) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash(CompareFloats(tol=1e-7,x=2e-6,y=2.01e-6)[0]) == 'f8320b26d30ab433c5a54546d21f414c'\n"
                                               ">>> assert get_hash(CompareFloats(tol=1e-7,x=2e-6,y=2.01e-6)[1]) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'Check default argument value.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
