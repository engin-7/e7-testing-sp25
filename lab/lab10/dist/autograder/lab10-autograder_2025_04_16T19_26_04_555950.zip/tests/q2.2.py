OK_FORMAT = True

test = {   'name': 'q2.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q2_2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(count_turn_back(np.array([1, 2, -1, -2, 3, -4, 5, -6]))) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n"
                                               ">>> assert get_hash(count_turn_back(np.array([1, -2, -1, 1, -2, 1, -3, 2, -6]))) == 'a87ff679a2f3e71d9181a67b7542122c'\n"
                                               ">>> assert get_hash(count_turn_back(np.array([-1, -1, 1, -2, 1, -3, 2, -6, 2]))) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n"
                                               '>>> assert get_hash(count_turn_back(np.array([1, -1, 1, -2, -2, 1, 1, -3, 2, -6, 1, -2, 4, -8, 2, -2, -2, 2]))) == '
                                               "'8f14e45fceea167a5a36dedd4bea2543'\n",
                                       'failure_message': 'Incorrect answer.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': ">>> assert get_hash(count_turn_back(np.array([1, 2, -1, -2, 3, -4, 5, -6]))) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n"
                                               ">>> assert get_hash(count_turn_back(np.array([1, -2, -1, 1, -2, 1, -3, 2, -6]))) == 'a87ff679a2f3e71d9181a67b7542122c'\n"
                                               ">>> assert get_hash(count_turn_back(np.array([-1, -1, 1, -2, 1, -3, 2, -6, 2]))) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n"
                                               ">>> assert get_hash(count_turn_back(np.array([1, -1, 1, -2, -2, 1, 1, -3, 2, -6, 1, -2, 4, -8, 2, -2, -2, 2]))) == '8f14e45fceea167a5a36dedd4bea2543'\n"
                                               ">>> assert callable(count_turn_back) and count_turn_back.__name__ == '<lambda>'\n",
                                       'failure_message': 'You need to write it as a lambda function for full credit.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
