OK_FORMAT = True

test = {   'name': 'q3.3',
    'points': 1.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q3_3)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(np.round(midpoint(-1, 1, 4), decimals=10)) == '4c9288729f4e8d6c06e16f93ca4a0291'\n"
                                               ">>> assert get_hash(np.round(midpoint(-1, 1, 16), decimals=10)) == 'b10a89f5b1130c329c745c38636a4e85'\n"
                                               ">>> assert get_hash(np.round(midpoint(1, 2, 10), decimals=10)) == 'ba41a1fc23a4f74d56dbbedbe623b303'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert get_hash(np.round(midpoint(-1.5, -0.5, 8), decimals=10)) == '53c7a1139243821727e7777d3726f56a'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(midpoint(-4, 4, 20), decimals=10)) == '3c139a5c1cd6e13e1a3d4ad5e3527e09'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
