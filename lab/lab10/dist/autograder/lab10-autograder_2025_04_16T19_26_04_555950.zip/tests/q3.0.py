OK_FORMAT = True

test = {   'name': 'q3.0',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q3_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(np.round(prob_density(0.0), decimals=10)) == '8b34af8fdef3efe96bb92c7e5c94c1a9'\n"
                                               ">>> assert get_hash(np.round(prob_density(1.0), decimals=10)) == 'ce9b517f150e250c0714b0c2f1706794'\n"
                                               ">>> assert get_hash(len(prob_density(np.linspace(-3, 3, 3)))) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n"
                                               ">>> assert get_hash(np.round(np.sum(prob_density(np.linspace(-3, 3, 3))), decimals=10)) == 'ff66233ef232fb604807dc368a2418e5'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert get_hash(np.round(prob_density(3.0), decimals=10)) == '7a4119a30cf776af10c5d15d4a88d1f6'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(prob_density(-2.0), decimals=10)) == '0b7ab1ceb5af4c0bf02becc62a6db1f1'\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> assert get_hash(len(prob_density(np.linspace(-4, 4)))) == 'c0c7c76d30bd3dcaefc96f40275bdc0a'\n"
                                               ">>> assert get_hash(np.round(np.sum(prob_density(np.linspace(-4, 4))), decimals=10)) == '7b52acb2d8c96f99ab3055413c17e8d7'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
