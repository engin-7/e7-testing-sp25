OK_FORMAT = True

test = {   'name': 'q1.4',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(fig)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> x = np.linspace(0, 10, 8) ** 4 / 4\n'
                                               '>>> t = np.linspace(0, 42, 8)\n'
                                               '>>> fig = plot_finite_difference(x, t)\n'
                                               '>>> plt.close()\n'
                                               '>>> fd, t1 = forward_diff(x, t)\n'
                                               '>>> bd, t2 = backward_diff(x, t)\n'
                                               '>>> cd, t3 = central_diff(x, t)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[0].get_xdata(), t1)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[0].get_ydata(), fd)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[1].get_xdata(), t2)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[1].get_ydata(), bd)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[2].get_xdata(), t3)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[2].get_ydata(), cd)\n',
                                       'failure_message': 'Check plot data.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> x = np.linspace(0, 10, 8) ** 4 / 4\n'
                                               '>>> t = np.linspace(0, 42, 8)\n'
                                               '>>> fig = plot_finite_difference(x, t)\n'
                                               '>>> plt.close()\n'
                                               ">>> assert 'FORWARD' in fig.axes[0].get_lines()[0].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'BACKWARD' in fig.axes[0].get_lines()[1].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'CENTRAL' in fig.axes[0].get_lines()[2].get_label().upper(), 'Check the line labels.'\n",
                                       'failure_message': 'Check line labels.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> x = np.linspace(0, 10, 8) ** 4 / 4\n'
                                               '>>> t = np.linspace(0, 42, 8)\n'
                                               '>>> fig = plot_finite_difference(x, t)\n'
                                               '>>> plt.close()\n'
                                               ">>> assert 'TIME' in fig.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert 'S' in fig.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert 'VELOCITY' in fig.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert 'FT' in fig.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert 'FINITE' in fig.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'DIFFERENCE' in fig.axes[0].get_title().upper(), 'Check the title label.'\n",
                                       'failure_message': 'Check title and axis labels.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> x = np.linspace(0, 10, 8) ** 4 / 4\n'
                                               '>>> t = np.linspace(0, 42, 8)\n'
                                               '>>> fig = plot_finite_difference(x, t)\n'
                                               '>>> plt.close()\n'
                                               ">>> assert type(fig.axes[0].get_legend()) != type(None), 'Make sure to add a legend.'\n"
                                               ">>> assert fig.axes[0].get_xlim() == (0, 45), 'Check the x-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_ylim() == (0, 200), 'Check the y-axis limits.'\n",
                                       'failure_message': 'Check legend and axis limits.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
