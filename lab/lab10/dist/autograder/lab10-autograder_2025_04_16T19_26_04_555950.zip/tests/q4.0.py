OK_FORMAT = True

test = {   'name': 'q4.0',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q4_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(np.round(arc_length(1.0, 2, 10), decimals=10)) == 'd0d34c32b571ab1fc2ea25a9ca390f0b'\n"
                                               ">>> assert get_hash(len(arc_length(np.linspace(0, 4, 5), 2, 10))) == 'e4da3b7fbbce2345d7772b0674a318d5'\n"
                                               ">>> assert get_hash(np.round(np.sum(arc_length(np.linspace(0, 4, 5), 2, 10)), decimals=10)) == '639440cf796ea06c52824c1e42f343e4'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert get_hash(np.round(arc_length(3, 3, 8), decimals=10)) == '52990045c97c8ca4e1f966bc87652929'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(len(arc_length(np.linspace(0, 10), 2, 10))) == 'c0c7c76d30bd3dcaefc96f40275bdc0a'\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(arc_length(np.linspace(0, 4, 5), 2, 10)), decimals=10)) == '639440cf796ea06c52824c1e42f343e4'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
