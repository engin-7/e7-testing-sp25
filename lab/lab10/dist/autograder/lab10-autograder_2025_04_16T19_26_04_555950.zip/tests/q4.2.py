OK_FORMAT = True

test = {   'name': 'q4.2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q4_2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(np.round(simpson(72, 1.5, 2 * np.pi, 50), decimals=10)) == 'ef9a02a994ddda85199530de13b307fb'\n"
                                               ">>> assert get_hash(np.round(simpson(108, 2, 10, 20), decimals=10)) == 'c8b0c8b0923bc98d754d89a26fbe6516'\n"
                                               ">>> assert get_hash(np.round(simpson(90, 2, 8, 30), decimals=10)) == '5011a5c8411e94373f98674ff9a3a697'\n"
                                               ">>> assert 'EVEN' in simpson(90, 2, 8, 31).upper(), 'What if n is odd?'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert get_hash(np.round(simpson(70, 1, 2.5 * np.pi, 40), decimals=10)) == 'eef40182ece9a4820bef551a6a0e9de1'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(simpson(104, 1.5, 6, 18), decimals=10)) == '46dff30acef75fd487f695296a540347'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert 'EVEN' in simpson(80, 3, 4, 25).upper(), 'What if n is odd?'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(simpson(95, 4, 3, 30), decimals=8)) == '7fc96de2390b282a233d95d1de72e6f3'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
