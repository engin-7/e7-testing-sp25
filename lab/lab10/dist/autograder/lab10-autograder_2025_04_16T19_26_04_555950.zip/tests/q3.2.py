OK_FORMAT = True

test = {   'name': 'q3.2',
    'points': 1.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q3_2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(np.round(right_riemann(-1, 1, 4), decimals=10)) == 'ad2d82776c936896c7f64c4dff6bb951'\n"
                                               ">>> assert get_hash(np.round(right_riemann(-1, 1, 16), decimals=10)) == '1b754edc46166d9b90edcd24b2112b60'\n"
                                               ">>> assert get_hash(np.round(right_riemann(1, 2, 10), decimals=10)) == '27236cfdd41b40528e62f1514118f87d'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert get_hash(np.round(right_riemann(-1.5, -0.5, 8), decimals=10)) == 'ec642eef16100a258f3c54f143290414'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(right_riemann(-4, 4, 20), decimals=10)) == '6797f80da99d42f847e6932fbd055dc6'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
