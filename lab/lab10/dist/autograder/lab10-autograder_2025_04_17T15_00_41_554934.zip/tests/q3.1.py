OK_FORMAT = True

test = {   'name': 'q3.1',
    'points': 1.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q3_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(np.round(left_riemann(-1, 1, 4), decimals=10)) == 'ad2d82776c936896c7f64c4dff6bb951'\n"
                                               ">>> assert get_hash(np.round(left_riemann(-1, 1, 16), decimals=10)) == '1b754edc46166d9b90edcd24b2112b60'\n"
                                               ">>> assert get_hash(np.round(left_riemann(1, 2, 10), decimals=10)) == 'd38ab5c6c1b4fc61cc19508e23f718bd'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert get_hash(np.round(left_riemann(-1.5, -0.5, 8), decimals=10)) == 'f7bf5801475b6d45ae3b4c69ca782639'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(left_riemann(-4, 4, 20), decimals=10)) == '6797f80da99d42f847e6932fbd055dc6'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
