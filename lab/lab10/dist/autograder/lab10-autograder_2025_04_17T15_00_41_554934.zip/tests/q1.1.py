OK_FORMAT = True

test = {   'name': 'q1.1',
    'points': 1.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> x = np.linspace(0, 10, 8) ** 4 / 4\n'
                                               '>>> t = np.linspace(0, 42, 8)\n'
                                               '>>> fd, t = backward_diff(x, t)\n'
                                               ">>> assert get_hash(len(t)) == '8f14e45fceea167a5a36dedd4bea2543'\n"
                                               ">>> assert get_hash(np.round(np.sum(t), decimals=10)) == 'c5f65ca2e1e8a6f25865540afab313b1'\n",
                                       'failure_message': 'Check output array of times t.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.4},
                                   {   'code': '>>> x = np.linspace(0, 10, 8) ** 4 / 4\n'
                                               '>>> t = np.linspace(0, 42, 8)\n'
                                               '>>> fd, t = backward_diff(x, t)\n'
                                               ">>> assert get_hash(len(fd)) == '8f14e45fceea167a5a36dedd4bea2543'\n"
                                               ">>> assert get_hash(np.round(np.sum(fd), decimals=10)) == '6db8caba1bdd7181a7c3b4687e118eea'\n",
                                       'failure_message': 'Check output array of derivatives.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.4},
                                   {   'code': '>>> t = np.linspace(0, 50, 9)\n'
                                               '>>> x = np.sin(t) * np.linspace(0, 1600, 9)\n'
                                               '>>> fd, t = backward_diff(x, t)\n'
                                               ">>> assert get_hash(len(fd)) == 'c9f0f895fb98ab9159f51fd0297e236d'\n"
                                               ">>> assert get_hash(np.round(np.sum(fd), decimals=10)) == '055595b5b0fc91c6d15d456ed9105fe8'\n"
                                               ">>> assert get_hash(len(t)) == 'c9f0f895fb98ab9159f51fd0297e236d'\n"
                                               ">>> assert get_hash(np.round(np.sum(t), decimals=10)) == 'c042f0232a75771cef34438527aceea0'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
