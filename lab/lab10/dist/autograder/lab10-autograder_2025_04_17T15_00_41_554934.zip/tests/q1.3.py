OK_FORMAT = True

test = {   'name': 'q1.3',
    'points': 1.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_3)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> x = np.linspace(0, 10, 8) ** 4 / 4\n'
                                               '>>> t = np.linspace(0, 42, 8)\n'
                                               '>>> fd, t = second_central_diff(x, t)\n'
                                               ">>> assert get_hash(len(t)) == '1679091c5a880faf6fb5e6087eb1b2dc'\n"
                                               ">>> assert get_hash(np.round(np.sum(t), decimals=10)) == '178a6d937373f4343f511ee76ace65b0'\n",
                                       'failure_message': 'Check output array of times t.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.4},
                                   {   'code': '>>> x = np.linspace(0, 10, 8) ** 4 / 4\n'
                                               '>>> t = np.linspace(0, 42, 8)\n'
                                               '>>> fd, t = second_central_diff(x, t)\n'
                                               ">>> assert get_hash(len(fd)) == '1679091c5a880faf6fb5e6087eb1b2dc'\n"
                                               ">>> assert get_hash(np.round(np.sum(fd), decimals=10)) == '788d08507cc9e1090ef43e3d012d1eaf'\n",
                                       'failure_message': 'Check output array of derivatives.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.4},
                                   {   'code': '>>> t = np.linspace(0, 50, 9)\n'
                                               '>>> x = np.sin(t) * np.linspace(0, 1600, 9)\n'
                                               '>>> fd, t = second_central_diff(x, t)\n'
                                               ">>> assert get_hash(len(fd)) == '8f14e45fceea167a5a36dedd4bea2543'\n"
                                               ">>> assert get_hash(np.round(np.sum(fd), decimals=10)) == 'c17fff3e6d2799be199547f9c21904fd'\n"
                                               ">>> assert get_hash(len(t)) == '8f14e45fceea167a5a36dedd4bea2543'\n"
                                               ">>> assert get_hash(np.round(np.sum(t), decimals=10)) == '740ac294e64275dedc766369887de09f'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
