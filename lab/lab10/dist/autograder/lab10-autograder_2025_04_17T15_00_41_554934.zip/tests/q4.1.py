OK_FORMAT = True

test = {   'name': 'q4.1',
    'points': 1.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q4_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(np.round(trapezoid(72, 1.5, 2 * np.pi, 50), decimals=10)) == '42a7a136a6bbbef36cfd80db70b9bd08'\n"
                                               ">>> assert get_hash(np.round(trapezoid(108, 2, 10, 20), decimals=10)) == '46ee9026714da49e3bbae76956e490d6'\n"
                                               ">>> assert get_hash(np.round(trapezoid(90, 2, 8, 30), decimals=10)) == '7686253236806613db4ec7675ff508fd'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert get_hash(np.round(trapezoid(70, 1, 2.5 * np.pi, 40), decimals=10)) == '9947f9ab48a52d3a4a0fbf0d289ce5de'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(trapezoid(104, 1.5, 6, 18), decimals=10)) == '25dbefa67086af7d844dcbcc4b93791d'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(trapezoid(80, 3, 4, 25), decimals=10)) == '6e2aadd1c7a6cc810c611a400ab7b05c'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(trapezoid(95, 4, 3, 30), decimals=10)) == 'aca22c5172f8041ae1b69abd3f8cfe1d'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
