OK_FORMAT = True

test = {   'name': 'q2.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(len(ant_t)) == '3644a684f98ea8fe223c713b77189a77'\n"
                                               ">>> assert get_hash(round(sum(ant_t), 10)) == '6afee53fff721cd3a9cb842db805c21d'\n",
                                       'failure_message': 'Check ant_time',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(len(ant_x)) == '3644a684f98ea8fe223c713b77189a77'\n"
                                               ">>> assert get_hash(round(sum(ant_x), 10)) == '7e849871d7ba4a42baa29eff17313f97'\n",
                                       'failure_message': 'Check ant_time',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
