OK_FORMAT = True

test = {   'name': 'q4.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> import scipy\n>>> assert get_hash(type(q4_3)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> import scipy\n'
                                               ">>> assert get_hash(np.round(quad(72, 1.5, 2 * np.pi), decimals=10)) == 'f8e153d2b8a8b43dffd2cdcac134034d'\n"
                                               ">>> assert get_hash(np.round(quad(108, 2, 10), decimals=10)) == '5b57094531e509e038eca980fb5eeda5'\n"
                                               ">>> assert get_hash(np.round(quad(90, 2, 8), decimals=10)) == 'cbf0055f331942bcaffb7e1ec532f273'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> import scipy\n>>> assert get_hash(np.round(quad(70, 1, 2.5 * np.pi), decimals=10)) == '6f0f32faba0632dccd715186aa42876b'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> import scipy\n>>> assert get_hash(np.round(quad(60, 1.5, 6), decimals=10)) == '183d04f158b4af6c7f4bfd1702becbc6'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> import scipy\n>>> assert get_hash(np.round(quad(30, 3, 4), decimals=10)) == '13a57b2f2e698f2a5f9c25362f7ef504'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> import scipy\n>>> assert get_hash(np.round(quad(27, 3, 5), decimals=10)) == 'a863fe878857f903a16f57180102b505'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
