OK_FORMAT = True

test = {   'name': 'q2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> import inspect\n>>> assert any([True if 'for' in line or 'while' in line else False for line in inspect.getsourcelines(nth_root)[0][1:]])\n",
                                       'failure_message': 'Your function should use iteration!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(np.round(nth_root(27, 3, 0, 10), 10)) == '55c82b601deae028c1c5e87fd820923d'\n"
                                               ">>> assert get_hash(np.round(nth_root(27, 3, 0, 10, maxiter=50), 10)) == '55c82b601deae028c1c5e87fd820923d'\n"
                                               ">>> assert get_hash(np.round(nth_root(27, 3, 0, 10, tol=0.001), 10)) == 'a39f3bb3a6fabd52f31cfed038561c13'\n"
                                               ">>> assert get_hash(np.round(nth_root(256, 4, 0, 5), 10)) == '07078a97d66756f213dbca3e379bf084'\n"
                                               ">>> assert get_hash(np.round(nth_root(256, 4, -5, 0), 10)) == '875e88e1e07100951fd600d433642d16'\n"
                                               '>>> import inspect\n'
                                               ">>> assert any([True if 'for' in line or 'while' in line else False for line in inspect.getsourcelines(nth_root)[0][1:]])\n",
                                       'failure_message': 'Test your function for the given exampes. Check the default argument values.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(np.round(nth_root(100, 5, 0, 10, tol=0.01), 10)) == 'a871b443d3b5b719440e0de48a321834'\n"
                                               ">>> assert get_hash(np.round(nth_root(100, 5, 0, 10, tol=1e-08), 10)) == 'b5f3a7bb40caeee1ae1bb6e8f3a5d142'\n"
                                               ">>> assert get_hash(np.round(nth_root(100, 5, 0, 10, maxiter=20), 10)) == '1503893c8918627e2f4fe72fd0c2e53c'\n"
                                               ">>> assert get_hash(np.round(nth_root(100, 5, 0, 10, maxiter=40), 10)) == 'b5f3a7bb40caeee1ae1bb6e8f3a5d142'\n"
                                               ">>> assert get_hash(np.round(nth_root(100, 5, 0, 10, maxiter=10, tol=1e-10), 10)) == '7c7f40e5283b4afb4424050988876205'\n"
                                               '>>> import inspect\n'
                                               ">>> assert any([True if 'for' in line or 'while' in line else False for line in inspect.getsourcelines(nth_root)[0][1:]])\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(np.round(nth_root(2, 2, 0, 2, tol=1), 10)) == 'e4c2e8edac362acab7123654b9e73432'\n",
                                       'failure_message': 'Your function should terminate when |f(r)| is either less than or equal to tol.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
