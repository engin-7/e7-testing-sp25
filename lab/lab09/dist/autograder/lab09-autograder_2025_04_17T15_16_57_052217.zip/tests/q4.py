OK_FORMAT = True

test = {   'name': 'q4',
    'points': 4,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q4)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> k1, k2, t0 = (1000, 0.6, 5.1)\n'
                                               ">>> assert get_hash(np.round(damping_root(k1, k2, t0, method='newton'), decimals=10)) == 'ad9995c0d305d650bc1a138f32113af7'\n"
                                               ">>> assert get_hash(np.round(damping_root(k1, k2, t0, method='fsolve'), decimals=10)) == 'ad9995c0d305d650bc1a138f32113af7'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> k1, k2, t0 = (1000, 0.6, 4.9)\n'
                                               ">>> assert get_hash(np.round(damping_root(k1, k2, t0, method='newton'), decimals=10)) == '6008647277c4454cecd97d33c069f0ca'\n"
                                               ">>> assert get_hash(np.round(damping_root(k1, k2, t0, method='fsolve'), decimals=10)) == 'ad9995c0d305d650bc1a138f32113af7'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> k1, k2, t0 = (1000, 0.6, 4.9)\n'
                                               ">>> assert isinstance(damping_root(k1, k2, t0, method='bisection'), str), 'Make sure to handle invalid inputs.'\n"
                                               ">>> assert 'INVALID' in damping_root(k1, k2, t0, method='bisection').upper(), 'Check invalid input message.'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> k1, k2, t0 = (800, 2, 2)\n'
                                               ">>> assert get_hash(np.round(damping_root(k1, k2, t0, method='newton'), decimals=10)) == '845e85fa64a2d6037055beba19fe0bd8'\n"
                                               ">>> assert get_hash(np.round(damping_root(k1, k2, t0, method='fsolve'), decimals=10)) == 'e3e5a4e071b34019caec47bec758eaa9'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> k1, k2, t0 = (800, 2, 3)\n'
                                               ">>> assert get_hash(np.round(damping_root(k1, k2, t0, method='newton'), decimals=10)) == 'eab7e959c5707439b9e2c1fe3e86d60c'\n"
                                               ">>> assert get_hash(np.round(damping_root(k1, k2, t0, method='fsolve'), decimals=10)) == '3dd2811ad4cc449e9f07df837559dc63'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
