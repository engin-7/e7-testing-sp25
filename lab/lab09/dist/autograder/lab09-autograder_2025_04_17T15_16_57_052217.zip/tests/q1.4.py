OK_FORMAT = True

test = {   'name': 'q1.4',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_4)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(len(mySinRange(5, 1e-08))) == 'c81e728d9d4c2f636f067f89cc14862c'\n",
                                       'failure_message': 'Check output length.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(np.round(mySinRange(5, 0.1)[0], 8)) == '9c41dab8e025b5db402b00cface5d381'\n"
                                               ">>> assert get_hash(np.round(mySinRange(5, 0.1)[1], 8)) == 'ee7b630995e7a36b6420696989441e2d'\n"
                                               ">>> assert get_hash(np.round(mySinRange(5, 0.001)[0], 8)) == 'c917a9e190d0c94c49ff24bab517b799'\n"
                                               ">>> assert get_hash(np.round(mySinRange(5, 0.001)[1], 8)) == '1089492f2ada616b051abde7ed35ebf2'\n"
                                               ">>> assert get_hash(np.round(mySinRange(5, 1e-08)[0], 8)) == '0262452e00cc917efe9134ae8192100c'\n"
                                               ">>> assert get_hash(np.round(mySinRange(5, 1e-08)[1], 8)) == '26cddfda7149a4fce6fa2a47f4c2af32'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
