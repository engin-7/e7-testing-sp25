OK_FORMAT = True

test = {   'name': 'q1.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> error, next_term = mySinError(np.array([2 * np.pi]), 5)\n'
                                               ">>> assert get_hash(np.round(np.sum(error), 8)) == '4b9473aa3637ebc2d2f2f81f61faa399', 'Check error.'\n"
                                               ">>> assert get_hash(np.round(np.sum(next_term), 8)) == 'b6bf808b29bf005e1758841a65038ed8', 'Check next term.'\n"
                                               '>>> error, next_term = mySinError(np.array([2 * np.pi]), 10)\n'
                                               ">>> assert get_hash(np.round(np.sum(error), 8)) == '1342c198f5fa4fbda5916561745c34a9', 'Check error.'\n"
                                               ">>> assert get_hash(np.round(np.sum(next_term), 8)) == '01ca83610c11fd5338f7e818ba84f1ca', 'Check next term.'\n",
                                       'failure_message': 'Check your function for scalar inputs.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> error, next_term = mySinError(np.linspace(-np.pi, np.pi, 4), 10)\n'
                                               ">>> assert get_hash(np.round(np.sum(error), 8)) == '30565a8911a6bb487e3745c0ea3c8224', 'Check error.'\n"
                                               ">>> assert get_hash(np.round(np.sum(next_term), 8)) == '30565a8911a6bb487e3745c0ea3c8224', 'Check next term.'\n"
                                               '>>> error, next_term = mySinError(np.linspace(-np.pi, np.pi, 4), 5)\n'
                                               ">>> assert get_hash(np.round(np.sum(error), 8)) == '3a27dec9b3b10fbcef90e55e1f2d4216', 'Check error.'\n"
                                               ">>> assert get_hash(np.round(np.sum(next_term), 8)) == 'a0baefa6c0d8c8ca7de6dca65419858e', 'Check next term.'\n",
                                       'failure_message': 'Check your function for array inputs.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
