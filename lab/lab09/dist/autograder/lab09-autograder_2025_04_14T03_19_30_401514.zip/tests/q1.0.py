OK_FORMAT = True

test = {   'name': 'q1.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_0)) != '14e736438b115821cbb9b7ac0ba79034', 'Make sure to test your function!'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(np.round(mySin(np.array([np.pi / 2]), 1), 12)[0]) == '1a719dcf1663212100d2e67bde1bf011'\n"
                                               ">>> assert get_hash(np.round(mySin(np.array([np.pi / 2]), 5), 12)[0]) == 'c33503c8532ac302a28dec7a8695083d'\n"
                                               ">>> assert get_hash(np.round(mySin(np.array([10.0]), 1), 12)[0]) == '43a1437f7f656cd8be7c996c58719e0a'\n"
                                               ">>> assert get_hash(np.round(mySin(np.array([10.0]), 5), 12)[0]) == '6b7a412ebdb1a3044003351946322472'\n",
                                       'failure_message': 'Check your function for scalar inputs.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(mySin(np.linspace(0.0, np.pi, 3), 7)), 10)) == 'cf7988d6e2f41dd2f7eca367f29558bb'\n"
                                               ">>> assert get_hash(np.round(np.sum(mySin(np.linspace(0.0, 10.0), 3)), 10)) == '1fc388c955f6e4ed2ccdd2379b968351'\n"
                                               '>>> assert get_hash(np.round(np.sum(mySin(np.array([[np.pi / 6, np.pi / 4], [np.pi / 3, np.pi / 2]]), 10)), 10)) == '
                                               "'8ce5dd44763bbd30ef1d3d8cf2992db4'\n"
                                               ">>> assert get_hash(np.round(np.sum(mySin(np.array([[1.0, 2.0], [3.0, 4.0]]), 5)), 10)) == '9523d598a5b97178a8fa479092c86df3'\n",
                                       'failure_message': 'Check your function for array inputs.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
