OK_FORMAT = True

test = {   'name': 'q3.1',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q3_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3},
                                   {   'code': '>>> f = lambda x: x ** 2 - 2\n'
                                               '>>> df = lambda x: 2 * x\n'
                                               '>>> R, E = myNewton(f, df, 1, tol=1e-08)\n'
                                               ">>> assert get_hash(np.round(np.sum(R), 10)) == '88d32212b966dcee3ec29d0ce8ce3a01'\n"
                                               ">>> assert get_hash(np.round(np.sum(E), 10)) == 'e593e1d8d5bf70f56814ba2b88eddf1f'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> f = lambda x: math.sin(x) - math.cos(x)\n'
                                               '>>> df = lambda x: math.cos(x) + math.sin(x)\n'
                                               '>>> R, E = myNewton(f, df, 1, tol=1e-08)\n'
                                               ">>> assert get_hash(np.round(np.sum(R), 10)) == '69f4271567bb9d14d8a22f79781461f5'\n"
                                               ">>> assert get_hash(np.round(np.sum(E), 10)) == 'd688dbef10264fd21dba0b0e5a6203b8'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> f = lambda x: math.sinh(x) - 1\n'
                                               '>>> df = lambda x: math.cosh(x)\n'
                                               '>>> R, E = myNewton(f, df, -1, tol=1e-08)\n'
                                               ">>> assert get_hash(np.round(np.sum(R), 10)) == '4bff05bbdee7affd4840dc1eeef9301e'\n"
                                               ">>> assert get_hash(np.round(np.sum(E), 10)) == 'd3ffbac1cf1deb56c0991c5732ecc6f8'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> f = lambda x: x ** 2 - 2\n'
                                               '>>> df = lambda x: 2 * x\n'
                                               '>>> R, E = myNewton(f, df, 1, tol=1)\n'
                                               ">>> assert get_hash(int(np.sum(R))) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               ">>> assert get_hash(int(np.sum(E))) == 'c4ca4238a0b923820dcc509a6f75849b'\n",
                                       'failure_message': 'Your function should terminate when |f(r)| is either less than or equal to tol.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
