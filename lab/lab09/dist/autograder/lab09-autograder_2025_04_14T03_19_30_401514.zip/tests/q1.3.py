OK_FORMAT = True

test = {   'name': 'q1.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_3)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(np.round(mySinPeriodic(np.array([1.0]), 10), 14)[0]) == '099c6f8b0fd2375bd1f67fd0361b42d6'\n"
                                               ">>> assert get_hash(np.round(mySinPeriodic(np.array([1 + 20 * np.pi]), 10), 14)[0]) == '099c6f8b0fd2375bd1f67fd0361b42d6'\n"
                                               ">>> assert get_hash(np.round(mySinPeriodic(np.array([-1.0]), 10), 14)[0]) == 'c1e44cffdfabeb1714daa8cbaec4abe8'\n"
                                               ">>> assert get_hash(np.round(mySinPeriodic(np.array([-1 - 20 * np.pi]), 10), 14)[0]) == 'c1e44cffdfabeb1714daa8cbaec4abe8'\n"
                                               ">>> assert get_hash(np.round(mySinPeriodic(np.array([2.0]), 10), 14)[0]) == '3dcc92152b4197b5132931b66178541c'\n"
                                               ">>> assert get_hash(np.round(mySinPeriodic(np.array([2 + 20 * np.pi]), 10), 14)[0]) == '3dcc92152b4197b5132931b66178541c'\n"
                                               ">>> assert get_hash(np.round(mySinPeriodic(np.array([-2.0]), 10), 14)[0]) == '6e5f88db7a4ea0b587bd9620e1056087'\n"
                                               ">>> assert get_hash(np.round(mySinPeriodic(np.array([-2 - 20 * np.pi]), 10), 14)[0]) == '6e5f88db7a4ea0b587bd9620e1056087'\n",
                                       'failure_message': 'Check your function for scalar inputs.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(mySinPeriodic(np.linspace(0, 5 * np.pi, 6), 10)), 8)) == '30565a8911a6bb487e3745c0ea3c8224'\n"
                                               ">>> assert get_hash(np.round(np.sum(mySinPeriodic(np.linspace(0, 5 * np.pi, 20), 5)), 8)) == '862314151b0333d3b2dfaaa23aca221a'\n"
                                               ">>> assert get_hash(np.round(np.sum(mySinPeriodic(np.linspace(-10 * np.pi, 5 * np.pi, 20), 5)), 8)) == 'b209fa8add1e3a19872f5411ef9b3d2f'\n"
                                               ">>> assert get_hash(np.round(np.sum(mySinPeriodic(np.linspace(-10 * np.pi, 5 * np.pi, 15), 10)), 8)) == '0df16f7567b8e2fbbaf8f129ef2e9480'\n",
                                       'failure_message': 'Check your function for array inputs.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
