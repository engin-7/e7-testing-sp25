OK_FORMAT = True

test = {   'name': 'q5.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q5_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {'code': ">>> assert get_hash(np.round(pipe_cost(10, 20, 10, 100, 50), decimals=8)) == '6db405727be0e7f3efb0113fcd810e41'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(pipe_cost(30, 20, 10, 100, 50), decimals=8)) == 'b9583ea216a7badcebe477e5819a1baf'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(pipe_cost(30, 15, 30, 40, 8), decimals=8)) == '7af1818bb9d1656e39edbde596314210'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(pipe_cost(5, 15, 30, 40, 8), decimals=8)) == '0cd1eaa83e3ef44c11378c3d74e0df0f'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
