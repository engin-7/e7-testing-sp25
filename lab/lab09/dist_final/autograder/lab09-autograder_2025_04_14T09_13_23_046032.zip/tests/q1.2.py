OK_FORMAT = True

test = {   'name': 'q1.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> N = 5\n'
                                               '>>> X = np.linspace(-N * np.pi / 2.0, N * np.pi / 2.0)\n'
                                               '>>> fig = PlotError(X, N)\n'
                                               ">>> plt.close('all')\n"
                                               '>>> error, next_term = mySinError(X, N)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[0].get_xdata(), X)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[0].get_ydata(), error)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[1].get_ydata(), next_term)\n',
                                       'failure_message': 'Check plot data.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> N = 5\n'
                                               '>>> X = np.linspace(-N * np.pi / 2.0, N * np.pi / 2.0)\n'
                                               '>>> fig = PlotError(X, N)\n'
                                               ">>> plt.close('all')\n"
                                               ">>> assert fig.axes[0].get_lines()[0].get_label() == 'Error', 'Check the line labels.'\n"
                                               ">>> assert fig.axes[0].get_lines()[1].get_label() == 'Next term', 'Check the line labels.'\n",
                                       'failure_message': 'Check line labels.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> N = 5\n'
                                               '>>> X = np.linspace(-N * np.pi / 2.0, N * np.pi / 2.0)\n'
                                               '>>> fig = PlotError(X, N)\n'
                                               ">>> plt.close('all')\n"
                                               ">>> assert 'X' in fig.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert 'ABSOLUTE' in fig.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert 'VALUE' in fig.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert str(N) in fig.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'TAYLOR' in fig.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'EXPANSION' in fig.axes[0].get_title().upper(), 'Check the title label.'\n",
                                       'failure_message': 'Check title and axis labels.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> N = 5\n'
                                               '>>> X = np.linspace(-N * np.pi / 2.0, N * np.pi / 2.0)\n'
                                               '>>> fig = PlotError(X, N)\n'
                                               ">>> plt.close('all')\n"
                                               ">>> assert type(fig.axes[0].get_legend()) != type(None), 'Make sure to add a legend.'\n"
                                               ">>> assert fig.axes[0].get_xlim() == (np.min(X), np.max(X)), 'Check the x-axis limits.'\n",
                                       'failure_message': 'Check legend and axis limits.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> plt.close('all')\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
