OK_FORMAT = True

test = {   'name': 'q3.0',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q3_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3},
                                   {   'code': '>>> f = lambda x: x ** 2 - 2\n'
                                               '>>> R, E = myBisection(f, 0, 2, tol=0.1)\n'
                                               ">>> assert get_hash(np.round(np.sum(R), 8)) == '50394ae342bd81e03fc7df6d588394fd'\n"
                                               ">>> assert get_hash(np.round(np.sum(E), 8)) == 'b795ad8086755bb5c29414e637bc617f'\n",
                                       'failure_message': 'Test your function for the given exampes.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> f = lambda x: math.sin(x) - math.cos(x)\n'
                                               '>>> R, E = myBisection(f, 0, 2, tol=0.01)\n'
                                               ">>> assert get_hash(np.round(np.sum(R), 8)) == '5ac0863af924d7974f9ae4f3e0e27f7b'\n"
                                               ">>> assert get_hash(np.round(np.sum(E), 8)) == '1c72cbd55836f1cf6e057fdb0f10d669'\n",
                                       'failure_message': 'Test your function for the given exampes.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> f = lambda x: math.exp(-x) - x ** 2\n'
                                               '>>> R, E = myBisection(f, 0, 1, tol=0.01)\n'
                                               ">>> assert get_hash(np.round(np.sum(R), 8)) == '222c230773e77edf87d79d18efc7ed9d'\n"
                                               ">>> assert get_hash(np.round(np.sum(E), 8)) == 'b5365dfa25be69a3214e3b667b8ec092'\n",
                                       'failure_message': 'Test your function for the given exampes.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> f = lambda x: x ** 2 - 2\n'
                                               '>>> R, E = myBisection(f, 0, 2, tol=1)\n'
                                               ">>> assert get_hash(int(np.sum(R))) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               ">>> assert get_hash(int(np.sum(E))) == 'c4ca4238a0b923820dcc509a6f75849b'\n",
                                       'failure_message': 'Your function should terminate when |f(r)| is either less than or equal to tol.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
