OK_FORMAT = True

test = {   'name': 'q5.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q5_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(pipe_builder(20, 10, 100, 50)), 8)) == '4b917bc475dc6f689e998b427a2c3658'\n"
                                               ">>> assert get_hash(np.round(np.sum(pipe_builder(30, 10, 100, 50)), 8)) == 'e593b6c24ff1bbf55b60b1ee98a00f3c'\n"
                                               ">>> assert get_hash(np.round(np.sum(pipe_builder(30, 10, 100, 20)), 8)) == '3a9fb245bdef7abab9e30a2fb6b1ac3a'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3},
                                   {'code': ">>> assert get_hash(np.round(np.sum(pipe_builder(10, 5, 10, 10)), 8)) == 'd29500ba4339881cbf0aa60519557c1e'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(np.sum(pipe_builder(20, 15, 100, 50)), 8)) == 'a1a21fe87a87f46a063123963258cad6'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(np.round(np.sum(pipe_builder(20, 15, 100, 10)), 8)) == '6f88ce0ace7663662c1d08a512ad6018'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
