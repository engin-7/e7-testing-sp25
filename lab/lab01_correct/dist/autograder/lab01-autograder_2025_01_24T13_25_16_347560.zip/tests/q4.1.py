OK_FORMAT = True

test = {   'name': 'q4.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               ">>> var_names = ['China_pop' , 'China_CO2' , 'Qatar_pop' , 'Qatar_CO2' , 'USA_pop' , 'USA_CO2']\n"
                                               '>>> assert all([var_name in globals() for var_name in var_names])\n',
                                       'failure_message': 'Check variable names.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> \n>>> assert get_hash(China_pop) == '0e4e946668cf2afc4299b462b812caca'\n>>> assert get_hash(China_CO2) == 'b7852f3d3a775b5188139a2c07024397'\n",
                                       'failure_message': 'Check China variable values.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> \n>>> assert get_hash(Qatar_pop) == '23cb05d4a2e5bf28363909d92cd244e2'\n>>> assert get_hash(Qatar_CO2) == '26657d5ff9020d2abefe558796b99584'\n",
                                       'failure_message': 'Check Qatar variable values.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> \n>>> assert get_hash(USA_pop) == 'c042f4db68f23406c6cecf84a7ebb0fe'\n>>> assert get_hash(USA_CO2) == '351869bde8b9d6ad1e3090bd173f600d'\n",
                                       'failure_message': 'Check USA variable values.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
