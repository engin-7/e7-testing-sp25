OK_FORMAT = True

test = {   'name': 'q1.0',
    'points': 3,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(secret_word.upper()) == '522c9d67b76b88d9bfb9dd7c9326f217'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
