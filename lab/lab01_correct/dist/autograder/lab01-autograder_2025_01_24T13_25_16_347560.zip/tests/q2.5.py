OK_FORMAT = True

test = {   'name': 'q2.5',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> assert get_hash(q2_5.upper()) == 'dfcf28d0734569a6a693bc8194de62bf'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Correct! Deadlines can be stressful. If you feel that you need to engage in academic misconduct to meet a deadline, please reach out to us. '
                                                          'We care that you learn the material and we are here to support you.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
