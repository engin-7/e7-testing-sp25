OK_FORMAT = True

test = {   'name': 'q2.1',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> assert get_hash(q2_1.upper()) == '0d61f8370cad1d412f80b84d143e1257'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Correct! Please do not email us to request short lab extensions, as 48 hours are granted by default.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
