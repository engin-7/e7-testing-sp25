OK_FORMAT = True

test = {   'name': 'q3.2',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q3_2) == 'eac1be4ceede350c62d93c8212e3e536'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
