OK_FORMAT = True

test = {   'name': 'q4.9',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> assert get_hash(round(q4_9a,3)) == '302ddfd6d63bbe5693b96981c129d3e2'\n>>> \n",
                                       'failure_message': 'Check q4_9a.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3},
                                   {   'code': ">>> \n>>> assert get_hash(round(q4_9b,3)) == '70e3b658922334c673fa2959dbfdfbd6'\n",
                                       'failure_message': 'Check q4_9b.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3},
                                   {'code': ">>> \n>>> assert get_hash(q4_9) == 'f8320b26d30ab433c5a54546d21f414c'\n", 'failure_message': 'Check q4_9.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
