OK_FORMAT = True

test = {   'name': 'q4.6',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q4_6) == 'f827cf462f62848df37c5e1e94a4da74'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
