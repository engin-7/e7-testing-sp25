OK_FORMAT = True

test = {   'name': 'q3.4',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q3_4, 3)) == '705214b9da419e4e6560a628f2d6396a'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
