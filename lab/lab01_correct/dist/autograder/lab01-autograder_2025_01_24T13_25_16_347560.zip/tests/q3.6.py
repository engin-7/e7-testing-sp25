OK_FORMAT = True

test = {   'name': 'q3.6',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(round(np.real(q3_6),8)) == 'c54490d3480079138c8c027a87a366e3'\n"
                                               ">>> assert get_hash(round(np.imag(q3_6),8)) == 'e4c2e8edac362acab7123654b9e73432'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
