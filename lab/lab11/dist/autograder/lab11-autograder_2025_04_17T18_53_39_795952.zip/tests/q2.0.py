OK_FORMAT = True

test = {   'name': 'q2.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q2_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> s0 = np.array([1, 2, 3])\n'
                                               '>>> sigma = 10\n'
                                               '>>> rho = 28\n'
                                               '>>> beta = 8 / 3\n'
                                               ">>> assert get_hash(len(my_lorenz(1, s0, sigma, rho, beta))) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n"
                                               ">>> assert get_hash(np.round(my_lorenz(1, s0, sigma, rho, beta)[0], decimals=8)) == '43a1437f7f656cd8be7c996c58719e0a'\n"
                                               ">>> assert get_hash(np.round(my_lorenz(1, s0, sigma, rho, beta)[1], decimals=8)) == '6bc071ec71e51c704acd13cdc898fd93'\n"
                                               ">>> assert get_hash(np.round(my_lorenz(1, s0, sigma, rho, beta)[2], decimals=8)) == 'ae425801d7761bbd0a54de7b7cbae62d'\n",
                                       'failure_message': 'Check given example.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 10\n'
                                               '>>> rho = 28\n'
                                               '>>> beta = 8 / 3\n'
                                               ">>> assert get_hash(len(my_lorenz(1, s0, sigma, rho, beta))) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n"
                                               ">>> assert get_hash(np.round(my_lorenz(1, s0, sigma, rho, beta)[0], decimals=8)) == '43a1437f7f656cd8be7c996c58719e0a'\n"
                                               ">>> assert get_hash(np.round(my_lorenz(1, s0, sigma, rho, beta)[1], decimals=8)) == 'c54490d3480079138c8c027a87a366e3'\n"
                                               ">>> assert get_hash(np.round(my_lorenz(1, s0, sigma, rho, beta)[2], decimals=8)) == '2767f7be09e208058dc7fc12936cfd38'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
