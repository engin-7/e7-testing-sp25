OK_FORMAT = True

test = {   'name': 'q3.4',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q3_4)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> m = 1\n'
                                               '>>> c = 0.5\n'
                                               '>>> k = 16\n'
                                               '>>> s0 = np.array([1, 0])\n'
                                               '>>> t_span = [0, 5]\n'
                                               '>>> n = 100\n'
                                               '>>> fig = my_msd_plot(t_span, n, s0, m, c, k)\n'
                                               '>>> plt.close()\n'
                                               '>>> ts_fe, xs_fe, _ = my_forward_euler(t_span, n, s0, m, c, k)\n'
                                               '>>> ts_be, xs_be, _ = my_backward_euler(t_span, n, s0, m, c, k)\n'
                                               '>>> ts_tr, xs_tr, _ = my_trapezoid(t_span, n, s0, m, c, k)\n'
                                               '>>> ts_ex = np.linspace(t_span[0], t_span[1], 10001)\n'
                                               '>>> xs_ex = msd_exact(ts_ex, m, c, k)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[0].get_xdata(), ts_fe)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[1].get_xdata(), ts_be)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[2].get_xdata(), ts_tr)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[3].get_xdata(), ts_ex)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[0].get_ydata(), xs_fe)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[1].get_ydata(), xs_be)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[2].get_ydata(), xs_tr)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[3].get_ydata(), xs_ex)\n',
                                       'failure_message': 'Check plot data.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> m = 1\n'
                                               '>>> c = 0.5\n'
                                               '>>> k = 16\n'
                                               '>>> s0 = np.array([1, 0])\n'
                                               '>>> t_span = [0, 5]\n'
                                               '>>> n = 100\n'
                                               '>>> fig = my_msd_plot(t_span, n, s0, m, c, k)\n'
                                               '>>> plt.close()\n'
                                               ">>> assert 'FORWARD' in fig.axes[0].get_lines()[0].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'BACKWARD' in fig.axes[0].get_lines()[1].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'TRAPEZOID' in fig.axes[0].get_lines()[2].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'EXACT' in fig.axes[0].get_lines()[3].get_label().upper(), 'Check the line labels.'\n",
                                       'failure_message': 'Check line labels.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> m = 1\n'
                                               '>>> c = 0.5\n'
                                               '>>> k = 16\n'
                                               '>>> s0 = np.array([1, 0])\n'
                                               '>>> t_span = [0, 5]\n'
                                               '>>> n = 100\n'
                                               '>>> fig = my_msd_plot(t_span, n, s0, m, c, k)\n'
                                               '>>> plt.close()\n'
                                               ">>> assert type(fig.axes[0].get_legend()) != type(None), 'Make sure to add a legend.'\n"
                                               ">>> assert fig.axes[0].get_xlim()[0] == t_span[0], 'Check the x-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_xlim()[1] == t_span[1], 'Check the x-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_ylim()[0] == -1.2, 'Check the y-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_ylim()[1] == 1.2, 'Check the y-axis limits.'\n",
                                       'failure_message': 'Check legend and axis limits.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> m = 1\n'
                                               '>>> c = 0.5\n'
                                               '>>> k = 16\n'
                                               '>>> s0 = np.array([1, 0])\n'
                                               '>>> t_span = [0, 5]\n'
                                               '>>> n = 100\n'
                                               '>>> fig = my_msd_plot(t_span, n, s0, m, c, k)\n'
                                               '>>> plt.close()\n'
                                               ">>> assert str(n) in fig.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert 'TIME' in fig.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert 'DISPLACEMENT' in fig.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n",
                                       'failure_message': 'Check title and axis labels.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> m = 1\n'
                                               '>>> c = 0.5\n'
                                               '>>> k = 16\n'
                                               '>>> s0 = np.array([1, 0])\n'
                                               '>>> t_span = [0, 5]\n'
                                               '>>> n = 10000\n'
                                               '>>> fig = my_msd_plot(t_span, n, s0, m, c, k)\n'
                                               '>>> plt.close()\n'
                                               '>>> ts_fe, xs_fe, _ = my_forward_euler(t_span, n, s0, m, c, k)\n'
                                               '>>> ts_be, xs_be, _ = my_backward_euler(t_span, n, s0, m, c, k)\n'
                                               '>>> ts_tr, xs_tr, _ = my_trapezoid(t_span, n, s0, m, c, k)\n'
                                               '>>> ts_ex = np.linspace(t_span[0], t_span[1], 10001)\n'
                                               '>>> xs_ex = msd_exact(ts_ex, m, c, k)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[0].get_xdata(), ts_fe)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[1].get_xdata(), ts_be)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[2].get_xdata(), ts_tr)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[3].get_xdata(), ts_ex)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[0].get_ydata(), xs_fe)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[1].get_ydata(), xs_be)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[2].get_ydata(), xs_tr)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[3].get_ydata(), xs_ex)\n',
                                       'failure_message': 'Check plot data.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> m = 1\n'
                                               '>>> c = 0.5\n'
                                               '>>> k = 16\n'
                                               '>>> s0 = np.array([1, 0])\n'
                                               '>>> t_span = [0, 5]\n'
                                               '>>> n = 10000\n'
                                               '>>> fig = my_msd_plot(t_span, n, s0, m, c, k)\n'
                                               '>>> plt.close()\n'
                                               ">>> assert str(n) in fig.axes[0].get_title().upper(), 'Check the title label.'\n"
                                               ">>> assert fig.axes[0].get_xlim()[0] == t_span[0], 'Check the x-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_xlim()[1] == t_span[1], 'Check the x-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_ylim()[0] == -1.2, 'Check the y-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_ylim()[1] == 1.2, 'Check the y-axis limits.'\n",
                                       'failure_message': 'Check title and axis limits work for other plot data.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
