OK_FORMAT = True

test = {   'name': 'q3.0',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q3_0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> A = my_msd(10, 1, 100)\n'
                                               ">>> assert get_hash(A.shape) == 'd2e4fdc3af210eddb2b758a08ecd487d'\n"
                                               ">>> assert get_hash(A[0, 0]) == '30565a8911a6bb487e3745c0ea3c8224'\n"
                                               ">>> assert get_hash(A[0, 1]) == 'e4c2e8edac362acab7123654b9e73432'\n"
                                               ">>> assert get_hash(A[1, 0]) == '5c81a10ecf7e02f1ec0a2fe656e4f161'\n"
                                               ">>> assert get_hash(A[1, 1]) == 'b4132a25aecd27236a53a2b1aabb7a75'\n",
                                       'failure_message': 'Check given examples.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> A = my_msd(5, 2, 40)\n'
                                               ">>> assert get_hash(A[0, 0]) == '30565a8911a6bb487e3745c0ea3c8224'\n"
                                               ">>> assert get_hash(A[0, 1]) == 'e4c2e8edac362acab7123654b9e73432'\n"
                                               ">>> assert get_hash(A[1, 0]) == '806dde96552addb686ab4265e264c021'\n"
                                               ">>> assert get_hash(A[1, 1]) == 'd1ab6103a7baf2fcf7a1611ac2299261'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
