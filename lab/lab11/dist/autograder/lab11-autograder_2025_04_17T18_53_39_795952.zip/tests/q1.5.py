OK_FORMAT = True

test = {   'name': 'q1.5',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_5)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> t_span = [0, 10]\n'
                                               '>>> P0 = 10\n'
                                               '>>> r = 1.01\n'
                                               '>>> K = 200\n'
                                               '>>> n = 10\n'
                                               '>>> fig = my_logistic_plot(t_span, n, P0, r, K)\n'
                                               '>>> plt.close()\n'
                                               '>>> ts_euler, Ps_euler = my_euler(t_span, n, P0, r, K)\n'
                                               '>>> ts_ivp, Ps_ivp = my_ivp(t_span, n, P0, r, K)\n'
                                               '>>> ts_mid, Ps_mid = my_midpoint(t_span, n, P0, r, K)\n'
                                               '>>> ts_heun, Ps_heun = my_heun(t_span, n, P0, r, K)\n'
                                               '>>> ts_exact = np.linspace(t_span[0], t_span[1], 10001)\n'
                                               '>>> Ps_exact = K * P0 * np.exp(r * ts_exact) / (K + P0 * (np.exp(r * ts_exact) - 1))\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[0].get_xdata(), ts_euler)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[1].get_xdata(), ts_mid)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[2].get_xdata(), ts_heun)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[3].get_xdata(), ts_ivp)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[4].get_xdata(), ts_exact)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[0].get_ydata(), Ps_euler)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[1].get_ydata(), Ps_mid)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[2].get_ydata(), Ps_heun)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[3].get_ydata(), Ps_ivp)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[4].get_ydata(), Ps_exact)\n',
                                       'failure_message': 'Check plot data.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> t_span = [0, 10]\n'
                                               '>>> P0 = 10\n'
                                               '>>> r = 1.01\n'
                                               '>>> K = 200\n'
                                               '>>> n = 10\n'
                                               '>>> fig = my_logistic_plot(t_span, n, P0, r, K)\n'
                                               '>>> plt.close()\n'
                                               ">>> assert 'FORWARD' in fig.axes[0].get_lines()[0].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'EULER' in fig.axes[0].get_lines()[0].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'MIDPOINT' in fig.axes[0].get_lines()[1].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'HEUN' in fig.axes[0].get_lines()[2].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'SOLVE_IVP' in fig.axes[0].get_lines()[3].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'EXACT' in fig.axes[0].get_lines()[4].get_label().upper(), 'Check the line labels.'\n",
                                       'failure_message': 'Check line labels.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> t_span = [0, 10]\n'
                                               '>>> P0 = 10\n'
                                               '>>> r = 1.01\n'
                                               '>>> K = 200\n'
                                               '>>> n = 10\n'
                                               '>>> fig = my_logistic_plot(t_span, n, P0, r, K)\n'
                                               '>>> plt.close()\n'
                                               ">>> assert 'FORWARD' in fig.axes[0].get_lines()[0].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'EULER' in fig.axes[0].get_lines()[0].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'MIDPOINT' in fig.axes[0].get_lines()[1].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'HEUN' in fig.axes[0].get_lines()[2].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'SOLVE_IVP' in fig.axes[0].get_lines()[3].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'EXACT' in fig.axes[0].get_lines()[4].get_label().upper(), 'Check the line labels.'\n"
                                               ">>> assert 'TIME' in fig.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert 'YEAR' in fig.axes[0].get_xlabel().upper(), 'Check the x-axis label.'\n"
                                               ">>> assert 'POPULATION' in fig.axes[0].get_ylabel().upper(), 'Check the y-axis label.'\n"
                                               ">>> assert str(n) in fig.axes[0].get_title().upper(), 'Check the title label.'\n",
                                       'failure_message': 'Check title and axis labels.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> t_span = [0, 10]\n'
                                               '>>> P0 = 10\n'
                                               '>>> r = 1.01\n'
                                               '>>> K = 200\n'
                                               '>>> n = 10\n'
                                               '>>> fig = my_logistic_plot(t_span, n, P0, r, K)\n'
                                               '>>> plt.close()\n'
                                               ">>> assert type(fig.axes[0].get_legend()) != type(None), 'Make sure to add a legend.'\n"
                                               ">>> assert fig.axes[0].get_xlim()[0] == t_span[0], 'Check the x-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_xlim()[1] == t_span[1], 'Check the x-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_ylim()[0] == 0, 'Check the y-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_ylim()[1] == K, 'Check the y-axis limits.'\n",
                                       'failure_message': 'Check legend and axis limits.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> t_span = [0, 10]\n'
                                               '>>> P0 = 10\n'
                                               '>>> r = 1.01\n'
                                               '>>> K = 200\n'
                                               '>>> n = 1000\n'
                                               '>>> fig = my_logistic_plot(t_span, n, P0, r, K)\n'
                                               '>>> plt.close()\n'
                                               '>>> ts_euler, Ps_euler = my_euler(t_span, n, P0, r, K)\n'
                                               '>>> ts_ivp, Ps_ivp = my_ivp(t_span, n, P0, r, K)\n'
                                               '>>> ts_exact = np.linspace(t_span[0], t_span[1], 10001)\n'
                                               '>>> Ps_exact = K * P0 * np.exp(r * ts_exact) / (K + P0 * (np.exp(r * ts_exact) - 1))\n'
                                               '>>> ts_mid, Ps_mid = my_midpoint(t_span, n, P0, r, K)\n'
                                               '>>> ts_heun, Ps_heun = my_heun(t_span, n, P0, r, K)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[0].get_xdata(), ts_euler)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[1].get_xdata(), ts_mid)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[2].get_xdata(), ts_heun)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[3].get_xdata(), ts_ivp)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[4].get_xdata(), ts_exact)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[0].get_ydata(), Ps_euler)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[1].get_ydata(), Ps_mid)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[2].get_ydata(), Ps_heun)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[3].get_ydata(), Ps_ivp)\n'
                                               '>>> assert np.allclose(fig.axes[0].get_lines()[4].get_ydata(), Ps_exact)\n',
                                       'failure_message': 'Check plot data.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import matplotlib.pyplot as plt\n'
                                               '>>> t_span = [0, 10]\n'
                                               '>>> P0 = 10\n'
                                               '>>> r = 1.01\n'
                                               '>>> K = 200\n'
                                               '>>> n = 1000\n'
                                               '>>> fig = my_logistic_plot(t_span, n, P0, r, K)\n'
                                               '>>> plt.close()\n'
                                               ">>> assert type(fig.axes[0].get_legend()) != type(None), 'Make sure to add a legend.'\n"
                                               ">>> assert fig.axes[0].get_xlim()[0] == t_span[0], 'Check the x-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_xlim()[1] == t_span[1], 'Check the x-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_ylim()[0] == 0, 'Check the y-axis limits.'\n"
                                               ">>> assert fig.axes[0].get_ylim()[1] == K, 'Check the y-axis limits.'\n",
                                       'failure_message': 'Check legend and axis limits.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
