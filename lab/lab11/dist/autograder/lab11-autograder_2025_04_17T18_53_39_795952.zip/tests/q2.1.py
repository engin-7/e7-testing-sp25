OK_FORMAT = True

test = {   'name': 'q2.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q2_1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> t_span = [0, 50]\n'
                                               '>>> n = 10000\n'
                                               '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 10\n'
                                               '>>> rho = 28\n'
                                               '>>> beta = 8 / 3\n'
                                               '>>> ts, xs, ys, zs = my_lorenz_RK4(t_span, n, s0, sigma, rho, beta)\n'
                                               ">>> assert get_hash(len(ts)) == 'd89f3a35931c386956c1a402a8e09941'\n"
                                               ">>> assert get_hash(len(xs)) == 'd89f3a35931c386956c1a402a8e09941'\n"
                                               ">>> assert get_hash(len(ys)) == 'd89f3a35931c386956c1a402a8e09941'\n"
                                               ">>> assert get_hash(len(zs)) == 'd89f3a35931c386956c1a402a8e09941'\n",
                                       'failure_message': 'Check length of output arrays.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 50]\n'
                                               '>>> n = 10000\n'
                                               '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 10\n'
                                               '>>> rho = 28\n'
                                               '>>> beta = 8 / 3\n'
                                               '>>> ts, xs, ys, zs = my_lorenz_RK4(t_span, n, s0, sigma, rho, beta)\n'
                                               ">>> assert get_hash(np.round(np.sum(ts), decimals=3)) == '1b89c997f160a81a81d1015a4541fc83'\n",
                                       'failure_message': 'Check output time array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 50]\n'
                                               '>>> n = 10000\n'
                                               '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 10\n'
                                               '>>> rho = 28\n'
                                               '>>> beta = 8 / 3\n'
                                               '>>> ts, xs, ys, zs = my_lorenz_RK4(t_span, n, s0, sigma, rho, beta)\n'
                                               ">>> assert get_hash(np.round(np.sum(xs), decimals=8)) == '56cc14aa6941ca75cf9e49df25d821a5'\n",
                                       'failure_message': 'Check output x array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 50]\n'
                                               '>>> n = 10000\n'
                                               '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 10\n'
                                               '>>> rho = 28\n'
                                               '>>> beta = 8 / 3\n'
                                               '>>> ts, xs, ys, zs = my_lorenz_RK4(t_span, n, s0, sigma, rho, beta)\n'
                                               ">>> assert get_hash(np.round(np.sum(ys), decimals=8)) == '33a828a9a22e8ca874bb90564ca7b71c'\n",
                                       'failure_message': 'Check output y array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 50]\n'
                                               '>>> n = 10000\n'
                                               '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 10\n'
                                               '>>> rho = 28\n'
                                               '>>> beta = 8 / 3\n'
                                               '>>> ts, xs, ys, zs = my_lorenz_RK4(t_span, n, s0, sigma, rho, beta)\n'
                                               ">>> assert get_hash(np.round(np.sum(zs), decimals=8)) == 'a0436a0211b70cd63f861d311e401a20'\n",
                                       'failure_message': 'Check output z array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 50]\n'
                                               '>>> n = 1000\n'
                                               '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 12\n'
                                               '>>> rho = 26\n'
                                               '>>> beta = 8 / 3\n'
                                               '>>> ts, xs, ys, zs = my_lorenz_RK4(t_span, n, s0, sigma, rho, beta)\n'
                                               ">>> assert get_hash(np.round(np.sum(xs), decimals=8)) == '3ea7a4aa3ba4ab7cc019151f44f3b048'\n"
                                               ">>> assert get_hash(np.round(np.sum(ys), decimals=8)) == 'c69f009852a0386cb1690533a4856b09'\n"
                                               ">>> assert get_hash(np.round(np.sum(zs), decimals=8)) == '92c5729b47e789b2441dddbb32b06e8e'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
