OK_FORMAT = True

test = {   'name': 'q1.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1_2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> t_span = [0, 10]\n'
                                               '>>> P0 = 10\n'
                                               '>>> r = 1.01\n'
                                               '>>> K = 200\n'
                                               '>>> n = 10\n'
                                               '>>> ts, Ps = my_midpoint(t_span, n, P0, r, K)\n'
                                               ">>> assert get_hash(len(ts)) == '6512bd43d9caa6e02c990b0a82652dca'\n"
                                               ">>> assert get_hash(np.round(np.sum(ts), decimals=8)) == 'e4878bf957c08a7ceaa9da9677015254'\n",
                                       'failure_message': 'Check time grid output.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.4},
                                   {   'code': '>>> t_span = [0, 10]\n'
                                               '>>> P0 = 10\n'
                                               '>>> r = 1.01\n'
                                               '>>> K = 200\n'
                                               '>>> n = 10\n'
                                               '>>> ts, Ps = my_midpoint(t_span, n, P0, r, K)\n'
                                               ">>> assert get_hash(len(Ps)) == '6512bd43d9caa6e02c990b0a82652dca'\n"
                                               ">>> assert get_hash(np.round(np.sum(Ps), decimals=8)) == '5c4b36213c5e9d7f899e852958eb727b'\n",
                                       'failure_message': 'Check solution output.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.4},
                                   {   'code': '>>> t_span = [0, 20]\n'
                                               '>>> P0 = 20\n'
                                               '>>> r = 1.1\n'
                                               '>>> K = 2000\n'
                                               '>>> n = 1000\n'
                                               '>>> ts, Ps = my_midpoint(t_span, n, P0, r, K)\n'
                                               ">>> assert get_hash(np.round(np.sum(ts), decimals=8)) == '61ee93b89af4fccf77f604ddbdbfc508'\n"
                                               ">>> assert get_hash(np.round(np.sum(Ps), decimals=8)) == '1c0a467778d5f9ddcf6cb4e50612b8bd'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
