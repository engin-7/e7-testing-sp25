OK_FORMAT = True

test = {   'name': 'q2.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q2_2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.2},
                                   {   'code': '>>> t_span = [0, 50]\n'
                                               '>>> n = 10000\n'
                                               '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 10\n'
                                               '>>> rho = 28\n'
                                               '>>> beta = 8 / 3\n'
                                               '>>> ts, xs, ys, zs = my_lorenz_ivp(t_span, n, s0, sigma, rho, beta)\n'
                                               ">>> assert get_hash(len(ts)) == 'd89f3a35931c386956c1a402a8e09941'\n"
                                               ">>> assert get_hash(len(xs)) == 'd89f3a35931c386956c1a402a8e09941'\n"
                                               ">>> assert get_hash(len(ys)) == 'd89f3a35931c386956c1a402a8e09941'\n"
                                               ">>> assert get_hash(len(zs)) == 'd89f3a35931c386956c1a402a8e09941'\n",
                                       'failure_message': 'Check length of output arrays.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 50]\n'
                                               '>>> n = 10000\n'
                                               '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 10\n'
                                               '>>> rho = 28\n'
                                               '>>> beta = 8 / 3\n'
                                               '>>> ts, xs, ys, zs = my_lorenz_ivp(t_span, n, s0, sigma, rho, beta)\n'
                                               ">>> assert get_hash(np.round(np.sum(ts), decimals=8)) == '1b89c997f160a81a81d1015a4541fc83'\n",
                                       'failure_message': 'Check values of output time array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 50]\n'
                                               '>>> n = 10000\n'
                                               '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 10\n'
                                               '>>> rho = 28\n'
                                               '>>> beta = 8 / 3\n'
                                               '>>> ts, xs, ys, zs = my_lorenz_ivp(t_span, n, s0, sigma, rho, beta)\n'
                                               ">>> assert get_hash(np.round(np.sum(xs), decimals=8)) == 'd3ed50912d27c877c8545da0fc95148c'\n",
                                       'failure_message': 'Check values of output x array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 50]\n'
                                               '>>> n = 10000\n'
                                               '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 10\n'
                                               '>>> rho = 28\n'
                                               '>>> beta = 8 / 3\n'
                                               '>>> ts, xs, ys, zs = my_lorenz_ivp(t_span, n, s0, sigma, rho, beta)\n'
                                               ">>> assert get_hash(np.round(np.sum(ys), decimals=8)) == '9ab4365cdc3cac7d70ae666f73b815fd'\n",
                                       'failure_message': 'Check values of output y array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 50]\n'
                                               '>>> n = 10000\n'
                                               '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 10\n'
                                               '>>> rho = 28\n'
                                               '>>> beta = 8 / 3\n'
                                               '>>> ts, xs, ys, zs = my_lorenz_ivp(t_span, n, s0, sigma, rho, beta)\n'
                                               ">>> assert get_hash(np.round(np.sum(zs), decimals=8)) == 'e3cd7b006761c754cb0921234f56e55b'\n",
                                       'failure_message': 'Check values of output z array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> t_span = [0, 50]\n'
                                               '>>> n = 1000\n'
                                               '>>> s0 = np.array([0, 1, 1.05])\n'
                                               '>>> sigma = 12\n'
                                               '>>> rho = 26\n'
                                               '>>> beta = 8 / 3\n'
                                               '>>> ts, xs, ys, zs = my_lorenz_ivp(t_span, n, s0, sigma, rho, beta)\n'
                                               ">>> assert get_hash(np.round(np.sum(xs), decimals=8)) == '43888ff417e9b6e321c5c9e554f6c3ef'\n"
                                               ">>> assert get_hash(np.round(np.sum(ys), decimals=8)) == '2015b91a2517d4dc3e95b4d18690f346'\n"
                                               ">>> assert get_hash(np.round(np.sum(zs), decimals=8)) == 'af991c2f41c17eb77accff22393b4601'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
