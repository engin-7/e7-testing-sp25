OK_FORMAT = True

test = {   'name': 'q1.1',
    'points': 0.25,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(elem_type_voters) == '9a86641cdf2fdb47f786dc955264738d'\n"
                                               ">>> assert get_hash(elem_type_candidates) == '9a86641cdf2fdb47f786dc955264738d'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
