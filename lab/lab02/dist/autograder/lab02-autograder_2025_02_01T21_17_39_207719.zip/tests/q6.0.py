OK_FORMAT = True

test = {   'name': 'q6.0',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               ">>> assert get_hash(fig1[0].upper()) == '00871030319cbec6a516cff2df01cab7'\n"
                                               ">>> assert get_hash(fig2[0].upper()) == 'ab05a7c024ce9e92c0c987edea417f6a'\n"
                                               ">>> assert get_hash(fig3[0].upper()) == 'ad274fcd8f530d1e1b1ddfa131eded78'\n",
                                       'failure_message': 'Check title.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               ">>> assert get_hash(len(fig1[1])) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(len(fig2[1])) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(len(fig3[1])) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               '>>> assert get_hash(int(sum(fig1[1]))) == get_hash(int(sum(reservoir_data[:,0])))\n'
                                               '>>> assert get_hash(int(sum(fig2[1]))) == get_hash(int(sum(reservoir_data[:,1])))\n'
                                               '>>> assert get_hash(int(sum(fig3[1]))) == get_hash(int(sum(reservoir_data[:,2])))\n',
                                       'failure_message': 'Check data.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
