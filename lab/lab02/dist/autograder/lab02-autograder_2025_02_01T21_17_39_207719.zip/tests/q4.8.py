OK_FORMAT = True

test = {   'name': 'q4.8',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q4_8) == '8f14e45fceea167a5a36dedd4bea2543'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
