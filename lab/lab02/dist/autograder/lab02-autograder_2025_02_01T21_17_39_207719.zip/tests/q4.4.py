OK_FORMAT = True

test = {   'name': 'q4.4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> assert get_hash(round(SummerMeanStorage)) == '118df32ac7db6de47c75d4ac84e6af2e'\n",
                                       'failure_message': 'Check mean calculation.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
