OK_FORMAT = True

test = {   'name': 'q1.0',
    'points': 0.25,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type_voters) == '425ed5b515f0a67c6316f0ec499f86bf'\n>>> assert get_hash(type_candidates) == '425ed5b515f0a67c6316f0ec499f86bf'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
