OK_FORMAT = True

test = {   'name': 'q4.3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(len(Diff)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(Diff.shape) == '3f30626b8bdbdc8366257c053839456f'\n"
                                               ">>> assert get_hash(sum(Diff)) == '4a3dd518aa065cd57d5d5acfeb1ff6da'\n"
                                               ">>> assert get_hash(Diff) == 'bde6ec575d6f776bfcb4df36f0e64c28'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
