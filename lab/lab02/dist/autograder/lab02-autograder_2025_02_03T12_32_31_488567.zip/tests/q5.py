OK_FORMAT = True

test = {   'name': 'q5',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> import calendar\n>>> assert get_hash(len(ReservoirInfo(name=reservoir_names[2], month=2))) == '735b90b4568125ed6c3f678819b6e058'\n",
                                       'failure_message': 'Check spacing and data type.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash(type(ReservoirInfo(name=reservoir_names[1], month=5).upper())) == '9a86641cdf2fdb47f786dc955264738d'\n",
                                       'failure_message': 'Check the return type.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash('HELD' in ReservoirInfo(name=reservoir_names[1], month=5).upper()) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash('WATER' in ReservoirInfo(name=reservoir_names[1], month=5).upper()) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'Check the wording.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash('SHASTA' in ReservoirInfo(name=reservoir_names[1], month=8).upper()) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash('OROVILLE' in ReservoirInfo(name=reservoir_names[0], month=8).upper()) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'Check the lake name.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash('MAY' in ReservoirInfo(name=reservoir_names[1], month=5).upper()) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash('JULY' in ReservoirInfo(name=reservoir_names[1], month=7).upper()) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash('FEBRUARY' in ReservoirInfo(name=reservoir_names[1], month=2).upper()) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'Check the month name.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {   'code': ">>> assert get_hash('1621000' in ReservoirInfo(name=reservoir_names[1], month=1)) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash('1690000' in ReservoirInfo(name=reservoir_names[1], month=2)) == 'f827cf462f62848df37c5e1e94a4da74'\n"
                                               ">>> assert get_hash('305100' in ReservoirInfo(name=reservoir_names[2], month=8)) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'Check storage value.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
