OK_FORMAT = True

test = {   'name': 'q4.5',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q4_5) == 'f8320b26d30ab433c5a54546d21f414c'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
