OK_FORMAT = True

test = {   'name': 'q3.2',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(len(q3_2)) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n", 'failure_message': 'Check length of list.', 'hidden': False, 'locked': False},
                                   {   'code': ">>> assert get_hash(q3_2[-1].upper()) == 'e5bb3ed8fc109fa9f05b0d538a30edf8'\n",
                                       'failure_message': 'Check value Hetch Hetchy entry.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
