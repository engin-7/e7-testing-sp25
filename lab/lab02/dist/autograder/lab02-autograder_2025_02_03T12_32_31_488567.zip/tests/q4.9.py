OK_FORMAT = True

test = {   'name': 'q4.9',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(len(reservoir_data_m3)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(reservoir_data_m3.shape) == '52658b9c1506282ca4f20ade14e21d99'\n"
                                               ">>> assert get_hash(sum(reservoir_data_m3)) == '4170ddab9b71a0810a7a6b5bb1e4444c'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
