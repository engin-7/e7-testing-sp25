OK_FORMAT = True

test = {   'name': 'q4.10',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(q4_10.shape) == '52658b9c1506282ca4f20ade14e21d99'\n"
                                               ">>> assert get_hash(np.issubdtype(q4_10.dtype, np.integer)) == 'f827cf462f62848df37c5e1e94a4da74'\n",
                                       'failure_message': 'Check the shape and type of the output. It should be an ndarray that has the same shape as the storage data.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash(type(q4_10[0, 0])) != '781f5f2052cfb496fa73d70ea1fbdaa8'\n",
                                       'failure_message': 'Check the data type of the entries.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': ">>> assert get_hash(sum(q4_10).astype(int)) == '91f3c39cea609dafc87061b3e6686199'\n"
                                               '>>> assert all([i == 0 for i in q4_10[:, -1]])\n'
                                               '>>> assert all([q4_10[i, 0] == 1 for i in range(len(q4_10[:, 0])) if i < 6])\n'
                                               '>>> assert all([q4_10[i, 0] == 0 for i in range(len(q4_10[:, 0])) if i > 5])\n'
                                               '>>> assert all([q4_10[i, 1] == 1 for i in range(1, len(q4_10[:, 1])) if i < 7])\n'
                                               '>>> assert all([q4_10[i, 1] == 0 for i in range(1, len(q4_10[:, 1])) if i > 6])\n',
                                       'failure_message': 'Check the entries of the output.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
