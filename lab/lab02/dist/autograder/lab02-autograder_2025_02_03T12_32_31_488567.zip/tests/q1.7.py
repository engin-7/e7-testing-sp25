OK_FORMAT = True

test = {   'name': 'q1.7',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(type(votes)) == '425ed5b515f0a67c6316f0ec499f86bf'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(len(votes)) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> assert get_hash(sum(votes)) == '0d98b597aa732aea606bde680c3b57d8'\n"
                                               ">>> assert get_hash(votes[0]) == '43e4e6a6f341e00671e123714de019a8'\n"
                                               ">>> assert get_hash(votes[1]) == '46a558d97954d0692411c861cf78ef79'\n"
                                               ">>> assert get_hash(votes[2]) == '2d2ca7eedf739ef4c3800713ec482e1a'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
