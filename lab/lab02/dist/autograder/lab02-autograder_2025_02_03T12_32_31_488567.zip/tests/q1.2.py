OK_FORMAT = True

test = {   'name': 'q1.2',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(int(num_voters)) == '0d98b597aa732aea606bde680c3b57d8'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
