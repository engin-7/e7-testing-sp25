OK_FORMAT = True

test = {   'name': 'q4.2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(len(EvenMonths)) == '1679091c5a880faf6fb5e6087eb1b2dc'\n",
                                       'failure_message': 'Check length of selection.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.3},
                                   {   'code': ">>> assert get_hash(EvenMonths.shape) == 'e186b2fc415e1b6085ca473fcc974c66'\n",
                                       'failure_message': 'Check slice selection.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5},
                                   {'code': ">>> assert get_hash(EvenMonths.astype(int)) == 'b2f43e102ce4fe6ac1033f199ea9cd4b'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
