OK_FORMAT = True

test = {   'name': 'q3.3',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(months_range) == '5319bc85f3a29d6cd7b6b65df958ae78'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(months_range[0]) == 'c4ca4238a0b923820dcc509a6f75849b'\n", 'failure_message': 'Check start value.', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(months_range[-1]) == 'c20ad4d76fe97759aa27a0c99bff6710'\n", 'failure_message': 'Check end value.', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(sum(months_range)) == '35f4a8d465e6e1edc05f3d8ab658c551'\n", 'failure_message': 'Check step size.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
