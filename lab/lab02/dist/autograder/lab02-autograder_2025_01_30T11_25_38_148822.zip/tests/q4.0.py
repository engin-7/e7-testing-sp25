OK_FORMAT = True

test = {   'name': 'q4.0',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> assert get_hash(len(OrovilleData)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n",
                                       'failure_message': 'Check length of selection.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {   'code': ">>> \n>>> assert get_hash(int(sum(OrovilleData))) == '97c2a51b4ddc77196fa563cd72957c1e'\n",
                                       'failure_message': 'Check which column corresponds to Lake Oroville.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.1},
                                   {'code': ">>> assert get_hash(OrovilleData.astype(int)) == 'd57f3682934eebd41c73b68817c6592d'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
