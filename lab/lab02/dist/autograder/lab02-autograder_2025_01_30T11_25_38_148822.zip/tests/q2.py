OK_FORMAT = True

test = {   'name': 'q2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> # Check data structure\n'
                                               '>>> for i in range(10):\n'
                                               '...     assert len(Repeat(i)) == i\n'
                                               '...     \n'
                                               '>>> for i in range(10,100):\n'
                                               '...     assert len(Repeat(i)) == i*2\n',
                                       'failure_message': 'Check spacing and data type.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.75},
                                   {   'code': ">>> \n>>> # Check the return type\n>>> assert get_hash(type(Repeat(n = 5))) == '9a86641cdf2fdb47f786dc955264738d'\n",
                                       'failure_message': 'Check the return type.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.25},
                                   {   'code': '>>> \n'
                                               '>>> # Check string output\n'
                                               ">>> assert get_hash(Repeat(1)) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               ">>> assert get_hash(Repeat(8)) == '8ddcff3a80f4189ca1c9d4d902c3c909'\n"
                                               ">>> assert get_hash(Repeat(12)) == '984719247dace834974b72df7923ee1f'\n"
                                               ">>> assert get_hash(Repeat(22)) == '67ba0218ba471508b94b07a22919454e'\n"
                                               ">>> assert get_hash(Repeat(75)) == 'ba50dbae347c4e5a95a241bec2c0b4da'\n",
                                       'failure_message': 'Check the output.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
