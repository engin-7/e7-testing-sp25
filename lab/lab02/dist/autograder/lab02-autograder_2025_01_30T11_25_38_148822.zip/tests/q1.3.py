OK_FORMAT = True

test = {   'name': 'q1.3',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(turnout_voters,10)) == '608880fae9997ba4bb218db46e20d6f4'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
