OK_FORMAT = True

test = {   'name': 'q1.5',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> # Check data structure\n>>> assert get_hash(len(VoterInfo(name=voters[0]))) == 'ea5d2f1c4608232e07d3aa3d998e5135'\n",
                                       'failure_message': 'Check spacing and data type.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> \n>>> # Check the return type\n>>> assert get_hash(type(VoterInfo(name=voters[0]))) == '9a86641cdf2fdb47f786dc955264738d'\n",
                                       'failure_message': 'Check the return type.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               '>>> # Check wording of string output\n'
                                               '>>> assert get_hash("RECENT" in VoterInfo(name=voters[0]).upper()) == \'f827cf462f62848df37c5e1e94a4da74\'\n'
                                               '>>> assert get_hash("ELECTIONS" in VoterInfo(name=voters[0]).upper()) == \'f827cf462f62848df37c5e1e94a4da74\'\n'
                                               '>>> assert get_hash("VOTED" in VoterInfo(name=voters[0]).upper()) == \'f827cf462f62848df37c5e1e94a4da74\'\n',
                                       'failure_message': 'Check the wording.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               '>>> # Check reservoir name\n'
                                               '>>> assert get_hash("MARIA WALKER" in VoterInfo(name=voters[7]).upper()) == \'f827cf462f62848df37c5e1e94a4da74\'\n'
                                               '>>> assert get_hash("DENNIS BOYD" in VoterInfo(name=voters[451]).upper()) == \'f827cf462f62848df37c5e1e94a4da74\'\n'
                                               '>>> assert get_hash("JAMES WILLIAMS" in VoterInfo(name=voters[6888]).upper()) == \'f827cf462f62848df37c5e1e94a4da74\'\n',
                                       'failure_message': 'Check the voter name.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> \n'
                                               '>>> # Check the name of the month\n'
                                               '>>> assert get_hash("TYLER DAVIS" in VoterInfo(name=voters[6201]).upper()) == \'f827cf462f62848df37c5e1e94a4da74\'\n'
                                               '>>> assert get_hash("LILA MARTINEZ" in VoterInfo(name=voters[2361]).upper()) == \'f827cf462f62848df37c5e1e94a4da74\'\n'
                                               '>>> assert get_hash("ZACH JOHNSON" in VoterInfo(name=voters[67]).upper()) == \'f827cf462f62848df37c5e1e94a4da74\'\n',
                                       'failure_message': "Check the candidate's name.",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
