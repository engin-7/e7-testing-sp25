OK_FORMAT = True

test = {   'name': 'q1.9',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q1_9) == 'f8320b26d30ab433c5a54546d21f414c'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
