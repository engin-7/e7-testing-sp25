OK_FORMAT = True

test = {   'name': 'q4.6',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(len(q4_6)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(q4_6.shape) == '3f30626b8bdbdc8366257c053839456f'\n"
                                               ">>> assert get_hash(q4_6) == '453afeb97740796e13cd9c391a6c9c86'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
