OK_FORMAT = True

test = {   'name': 'q1.6',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(int(votes_LM)) == '43e4e6a6f341e00671e123714de019a8'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
