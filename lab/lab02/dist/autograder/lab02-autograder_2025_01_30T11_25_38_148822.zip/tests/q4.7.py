OK_FORMAT = True

test = {   'name': 'q4.7',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(len(q4_7)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(q4_7.shape) == '3f30626b8bdbdc8366257c053839456f'\n"
                                               ">>> assert get_hash(q4_7) == 'bc1f55c0a039c7a0df8b2ece9ceda908'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
