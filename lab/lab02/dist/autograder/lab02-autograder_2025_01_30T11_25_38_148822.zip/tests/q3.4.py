OK_FORMAT = True

test = {   'name': 'q3.4',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               ">>> assert get_hash(type(months_list)) == '425ed5b515f0a67c6316f0ec499f86bf'\n"
                                               ">>> assert get_hash(len(months_list)) == 'c20ad4d76fe97759aa27a0c99bff6710'\n"
                                               ">>> assert get_hash(sum(months_list)) == '35f4a8d465e6e1edc05f3d8ab658c551'\n",
                                       'failure_message': 'Check months_list.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
