OK_FORMAT = True

test = {   'name': 'q6.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(q6_1_type) == '22b3afce62075c7012f8e5041adfee16'\n>>> assert get_hash(q6_1_length) == 'c81e728d9d4c2f636f067f89cc14862c'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
