OK_FORMAT = True

test = {   'name': 'q1.4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(amy_king_index) == '88ccf9a98e8519b2011df33952832f2f'\n"
                                               ">>> assert get_hash(amy_king_vote.upper()) == '25e5a1adec953dde8ae67b8fa66d3369'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
